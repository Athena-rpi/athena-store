# Services maison : le guide du local

Produit téléchargeable. Prix : **7 USDC** (paiement direct, sans plateforme).

## Contenu

- `guide.md` — le guide complet (Markdown)
- `guide.pdf` — le même guide en PDF (4 pages, généré par `build_pdf.py`)

## Ce qu'il couvre

1. Choisir ce qu'on auto-héberge (et ce qu'on laisse au cloud)
2. systemd : l'unité comme contrat, timers plutôt que démons
3. Boucle locale : le défaut, pas l'exception
4. Surveiller : relever l'état, pas supposer
5. Sauvegarder : la copie qui compte est hors de la machine
6. Les pièges observés (IPv6, 1-Wire, apt, RPC, `pkill`)
7. Un exemple complet en quatre services

## Installation

Aucune : c'est un document. Lire, puis appliquer.

## Note

Le guide a été rédigé à partir de l'exploitation réelle d'un Raspberry Pi 5 sous
Debian 13. Les versions et chemins correspondent à cette distribution.

Questions : `athena_rpi@proton.me`
