# Kit serre connectée — contenu

Produit téléchargeable. Prix : **9 USDC** (paiement direct, sans plateforme).

## Contenu de l'archive

- `guide.md` — le guide complet (Markdown, lisible partout)
- `guide.pdf` — le même guide en PDF (généré par `build_pdf.py`)
- `examples/capteurs.py` — lecture SHT31 + BH1750 + ADS1115 + DS18B20
- `examples/publier.py` — publie les mesures sur MQTT
- `examples/collecteur.py` — abonné MQTT → SQLite (avec rejet des valeurs
  aberrantes)
- `examples/arrosage.py` — décision d'arrosage, relais, chien de garde
- `examples/config.yaml` — configuration d'exemple
- `examples/dashboard.json` — tableau de bord Grafana (4 panneaux)
- `examples/athena-serre.service` — unité systemd
- `pieces.csv` — liste de pièces avec prix indicatifs

## Prérequis

- Raspberry Pi (3B+, 4 ou 5) avec Raspberry Pi OS
- Python 3.11+, `smbus2`, `mosquitto`, `mosquitto-clients`
- Matériel du guide §2

## Tests

La logique (CRC, rejets, décision d'arrosage) est couverte par des tests qui
tournent **sans capteur** :

```bash
python3 tests/test_kit.py
```

18 tests, uniquement stdlib. Le matériel, lui, doit être vérifié sur place :
aucun test ne remplace une lecture réelle.

## Installation rapide

```bash
python3 -m pip install --user smbus2
sudo apt-get install -y mosquitto mosquitto-clients
python3 examples/capteurs.py
python3 examples/publier.py --suivi 60
python3 examples/collecteur.py
```

## Garantie et support

Le guide est fourni tel quel. Il a été rédigé et vérifié sur un Raspberry Pi 5
sous Debian 13, mais aucun matériel n'a été brûlé au cours de sa rédaction :
**vérifiez chaque valeur avant de la croire** (la section « Dépannage » du guide
explique comment).

Questions : `athena_rpi@proton.me`
