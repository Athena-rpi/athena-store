#!/usr/bin/env python3
"""Génère guide.pdf à partir de guide.md (fpdf2, polices DejaVu).

Rendu volontairement simple : titres, paragraphes, listes, tableaux,
blocs de code, filets. Le Markdown reste la source de vérité.
"""
from __future__ import annotations

import os
import re
import sys

from fpdf import FPDF

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "guide.md")
OUT = os.path.join(ROOT, "guide.pdf")

FONT_DIR = "/usr/share/fonts/truetype/dejavu"
F_REG = os.path.join(FONT_DIR, "DejaVuSans.ttf")
F_BOLD = os.path.join(FONT_DIR, "DejaVuSans-Bold.ttf")
F_MONO = os.path.join(FONT_DIR, "DejaVuSansMono.ttf")

MARGE = 18
NOIR = (20, 22, 28)
GRIS = (90, 98, 110)
BLEU = (60, 90, 150)


class Doc(FPDF):
    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("reg", size=8)
        self.set_text_color(*GRIS)
        self.set_y(10)
        self.cell(0, 6, "Kit serre connectée — guide", align="R")
        self.line(MARGE, 18, self.w - MARGE, 18)

    def footer(self):
        self.set_y(-14)
        self.set_font("reg", size=8)
        self.set_text_color(*GRIS)
        self.cell(0, 8, f"page {self.page_no()}/{{nb}}", align="C")


def inline(text: str) -> str:
    """Conserve le texte mais retire les marqueurs que fpdf ne sait pas rendre."""
    text = text.replace("**", "")
    text = text.replace("`", "")
    return text


def main() -> int:
    if not os.path.exists(SRC):
        print(f"source absente : {SRC}")
        return 2
    for f in (F_REG, F_BOLD, F_MONO):
        if not os.path.exists(f):
            print(f"police absente : {f}")
            return 2

    pdf = Doc(format="A4", unit="mm")
    pdf.set_auto_page_break(True, margin=18)
    pdf.set_margins(MARGE, 20, MARGE)
    pdf.add_font("reg", "", F_REG)
    pdf.add_font("reg", "B", F_BOLD)
    pdf.add_font("mono", "", F_MONO)
    pdf.add_page()

    lignes = open(SRC, encoding="utf-8").read().splitlines()
    i = 0
    dans_code = False
    tableau: list[list[str]] = []

    def flush_tableau():
        nonlocal tableau
        if not tableau:
            return
        largeurs = [pdf.w - 2 * MARGE] * len(tableau[0])
        pdf.set_font("reg", size=8)
        for rang, ligne in enumerate(tableau):
            if rang == 1 and all(set(c.strip()) <= {"-", ":"} for c in ligne):
                continue
            for col, cellule in enumerate(ligne):
                style = "B" if rang == 0 else ""
                pdf.set_font("reg", style=style, size=8)
                pdf.set_fill_color(238, 241, 246) if rang == 0 else None
                pdf.cell((pdf.w - 2 * MARGE) / len(ligne), 6, inline(cellule.strip()), border=1,
                         fill=(rang == 0))
            pdf.ln()
        pdf.ln(2)
        tableau = []

    while i < len(lignes):
        pdf.set_x(MARGE)          # multi_cell laisse x au bord droit : on recentre
        l = lignes[i]

        if l.strip().startswith("```"):
            if dans_code:
                pdf.ln(2)
            dans_code = not dans_code
            i += 1
            continue

        if dans_code:
            pdf.set_font("mono", size=7.5)
            pdf.set_text_color(*NOIR)
            pdf.set_x(MARGE)
            pdf.multi_cell(pdf.w - 2 * MARGE, 4, l if l else " ", border=0)
            i += 1
            continue

        if l.startswith("|") and "|" in l[1:]:
            cellules = [c for c in l.strip().strip("|").split("|")]
            tableau.append(cellules)
            i += 1
            continue
        flush_tableau()

        if not l.strip():
            pdf.ln(2)
        elif l.startswith("### "):
            pdf.ln(1)
            pdf.set_font("reg", "B", 11)
            pdf.set_text_color(*NOIR)
            pdf.multi_cell(0, 5.5, inline(l[4:]))
        elif l.startswith("## "):
            pdf.ln(3)
            pdf.set_font("reg", "B", 13)
            pdf.set_text_color(*BLEU)
            pdf.multi_cell(0, 7, inline(l[3:]))
            pdf.line(MARGE, pdf.get_y() + 1, pdf.w - MARGE, pdf.get_y() + 1)
            pdf.ln(2)
        elif l.startswith("# "):
            pdf.set_font("reg", "B", 19)
            pdf.set_text_color(*NOIR)
            pdf.multi_cell(0, 9, inline(l[2:]))
        elif l.strip() == "---":
            pdf.ln(2)
            pdf.line(MARGE, pdf.get_y(), pdf.w - MARGE, pdf.get_y())
        elif l.lstrip().startswith(("- ", "* ")):
            pdf.set_font("reg", size=10)
            pdf.set_text_color(*NOIR)
            pdf.set_x(MARGE + 4)
            pdf.multi_cell(pdf.w - 2 * MARGE - 4, 5, "• " + inline(l.lstrip()[2:]))
        else:
            pdf.set_font("reg", size=10)
            pdf.set_text_color(*NOIR)
            pdf.multi_cell(0, 5, inline(l))
        i += 1

    flush_tableau()
    pdf.output(OUT)
    print(f"{OUT} ({os.path.getsize(OUT)} octets, {pdf.page_no()} pages)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
