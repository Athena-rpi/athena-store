#!/usr/bin/env python3
"""Tests du kit serre — uniquement stdlib (unittest).

Ces tests portent sur la **logique**, pas sur le matériel : le CRC du SHT31, le
rejet des valeurs aberrantes, et la décision d'arrosage. Ils tournent donc sur
n'importe quelle machine, sans capteur.

Lancer :
    python3 -m unittest discover -s tests -v
    python3 tests/test_kit.py
"""
from __future__ import annotations

import datetime
import importlib.util
import os
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent.parent
EX = ROOT / "examples"
sys.path.insert(0, str(EX))


def _import(nom: str, chemin: pathlib.Path):
    spec = importlib.util.spec_from_file_location(nom, chemin)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _a_midi():
    return datetime.datetime.now().replace(hour=12, minute=0, second=0, microsecond=0)


class TestCRC(unittest.TestCase):
    """Le CRC8 de Sensirion : polynomiale 0x31, initiale 0xFF."""

    @classmethod
    def setUpClass(cls):
        cls.capteurs = _import("capteurs", EX / "capteurs.py")

    def test_vecteur_connu_be_ef(self):
        # Valeur de référence des datasheets Sensirion : CRC(0xBEEF) = 0x92
        self.assertEqual(self.capteurs.crc8_sensirion(bytes([0xBE, 0xEF])), 0x92)

    def test_crc_depend_des_donnees(self):
        a = self.capteurs.crc8_sensirion(bytes([0x00, 0x00]))
        b = self.capteurs.crc8_sensirion(bytes([0xFF, 0xFF]))
        self.assertNotEqual(a, b)

    def test_crc_est_un_octet(self):
        for v in (0x00, 0x7F, 0x80, 0xFF):
            self.assertLessEqual(self.capteurs.crc8_sensirion(bytes([v])), 0xFF)


class TestHumiditeSol(unittest.TestCase):
    """L'humidité de sol est une tension étalonnée, clampée entre 0 et 100."""

    @classmethod
    def setUpClass(cls):
        cls.capteurs = _import("capteurs", EX / "capteurs.py")

    def test_aucune_tension(self):
        self.assertIsNone(self.capteurs.humidite_sol(None))

    def test_clamp_haut(self):
        self.assertEqual(self.capteurs.humidite_sol(0.0), 100.0)

    def test_clamp_bas(self):
        self.assertEqual(self.capteurs.humidite_sol(5.0), 0.0)

    def test_etalonnage_invalide(self):
        ancien = (self.capteurs.SOL_V_AIR, self.capteurs.SOL_V_EAU)
        self.capteurs.SOL_V_AIR, self.capteurs.SOL_V_EAU = 1.0, 2.0   # air < eau : incohérent
        try:
            self.assertIsNone(self.capteurs.humidite_sol(1.5))
        finally:
            self.capteurs.SOL_V_AIR, self.capteurs.SOL_V_EAU = ancien


class TestRejetsCollecteur(unittest.TestCase):
    """Le collecteur ne doit jamais écrire une valeur aberrante."""

    @classmethod
    def setUpClass(cls):
        cls.coll = _import("collecteur", EX / "collecteur.py")

    def setUp(self):
        f = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        f.close()
        self.tmp = f.name
        self.con = self.coll.ouvrir(self.tmp)

    def tearDown(self):
        self.con.close()
        os.unlink(self.tmp)

    def test_valeur_dans_la_plage_acceptee(self):
        self.assertTrue(self.coll.inserer(self.con, "serre/air/temperature", 23.4, "°C"))

    def test_valeur_hors_plage_rejetee(self):
        self.assertFalse(self.coll.inserer(self.con, "serre/air/temperature", 999.0, "°C"))
        self.assertEqual(self.con.execute("select count(*) from mesures").fetchone()[0], 0)

    def test_valeurs_bornes_acceptees(self):
        self.assertTrue(self.coll.inserer(self.con, "serre/air/humidite", 0.0, "%"))
        self.assertTrue(self.coll.inserer(self.con, "serre/air/humidite", 100.0, "%"))

    def test_topic_inconnu_ignore(self):
        self.assertFalse(self.coll.inserer(self.con, "serre/inconnu", 1.0, ""))

    def test_deux_capteurs_a_la_meme_seconde(self):
        """Régression : la clé primaire (ts, capteur) doit garder les deux."""
        self.assertTrue(self.coll.inserer(self.con, "serre/air/temperature", 20.0, "°C"))
        self.assertTrue(self.coll.inserer(self.con, "serre/lux", 500.0, "lux"))
        self.assertEqual(self.con.execute("select count(*) from mesures").fetchone()[0], 2)


class TestDecisionArrosage(unittest.TestCase):
    """La pompe ne démarre que si toutes les conditions sont réunies."""

    @classmethod
    def setUpClass(cls):
        cls.arr = _import("arrosage", EX / "arrosage.py")

    def _a(self, heure):
        t = datetime.datetime.now().replace(hour=heure, minute=0, second=0, microsecond=0)
        return mock.patch.object(self.arr, "datetime")

    def test_sol_sec_cuve_pleine_dans_la_plage(self):
        with mock.patch.object(self.arr, "datetime") as m:
            m.datetime.now.return_value = _a_midi()
            self.assertTrue(self.arr.decider(20.0, True, 0.0))

    def test_cuve_vide_bloque(self):
        with mock.patch.object(self.arr, "datetime") as m:
            m.datetime.now.return_value = _a_midi()
            self.assertFalse(self.arr.decider(10.0, False, 0.0))

    def test_sol_humide_bloque(self):
        with mock.patch.object(self.arr, "datetime") as m:
            m.datetime.now.return_value = _a_midi()
            self.assertFalse(self.arr.decider(80.0, True, 0.0))

    def test_donnee_absente_bloque(self):
        with mock.patch.object(self.arr, "datetime") as m:
            m.datetime.now.return_value = _a_midi()
            self.assertFalse(self.arr.decider(None, True, 0.0))

    def test_delai_minimal_bloque(self):
        with mock.patch.object(self.arr, "datetime") as m:
            m.datetime.now.return_value = _a_midi()
            self.assertFalse(self.arr.decider(20.0, True, self.arr.time.time() - 10))

    def test_hors_plage_horaire_bloque(self):
        with mock.patch.object(self.arr, "datetime") as m:
            m.datetime.now.return_value = _a_midi().replace(hour=23)
            self.assertFalse(self.arr.decider(20.0, True, 0.0))


if __name__ == "__main__":
    unittest.main(verbosity=2)
