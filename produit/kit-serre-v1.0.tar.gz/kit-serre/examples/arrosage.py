#!/usr/bin/env python3
"""Kit serre — décision d'arrosage et pilotage du relais (échoue fermé).

Règle :
    pompe ON 30 s  si  sol < SEUIL_SEC  et  cuve = 1  et  heure autorisée
    sinon           pompe OFF

Sécurités :
- le relais est **ouvert au repos** : un GPIO à 0 ou un Pi qui plante = pompe OFF ;
- un arrosage est limité en durée, et un nouveau cycle exige un délai minimal ;
- un chien de garde coupe la pompe si le dernier appel date de plus de WATCHDOG_S.

La broche est GPIO17 (BCM) par défaut. Logique 3,3 V, jamais 5 V.
"""
from __future__ import annotations

import argparse
import datetime
import sys
import time

try:
    import lgpio
except ImportError:
    lgpio = None

RELAY_PIN = 17
SEUIL_SEC = 25.0        # % d'humidité du sol
DUREE_S = 30            # secondes d'arrosage
DELAI_MIN_S = 600       # délai minimal entre deux cycles
WATCHDOG_S = 600        # coupure si le cœur n'a pas parlé
HEURE_DEBUT = 6
HEURE_FIN = 21


class Relais:
    """Sortie GPIO, basse tension, active haut. Défaut = fermé (pompe arrêtée)."""

    def __init__(self, pin: int = RELAY_PIN):
        self.pin = pin
        self.chip = None
        if lgpio is None:
            print("lgpio absent — le relais reste inactif", file=sys.stderr)
            return
        try:
            self.chip = lgpio.gpiochip_open(0)
            lgpio.gpio_claim_output(self.chip, pin, 0)   # 0 = pompe OFF
        except Exception as exc:  # noqa: BLE001
            print(f"GPIO indisponible ({exc}) — relais inactif", file=sys.stderr)
            self.chip = None

    def etat(self) -> bool:
        if self.chip is None:
            return False
        return bool(lgpio.gpio_read(self.chip, self.pin))

    def activer(self, on: bool) -> None:
        if self.chip is None:
            return
        lgpio.gpio_write(self.chip, self.pin, 1 if on else 0)

    def fermer(self) -> None:
        self.activer(False)
        if self.chip is not None:
            try:
                lgpio.gpiochip_close(self.chip)
            except Exception:  # noqa: BLE001
                pass


def decider(sol: float | None, cuve_pleine: bool, dernier_cycle: float) -> bool:
    """Vrai si un cycle d'arrosage doit démarrer."""
    if sol is None or not cuve_pleine:
        return False
    now = datetime.datetime.now()
    if not (HEURE_DEBUT <= now.hour < HEURE_FIN):
        return False
    if sol >= SEUIL_SEC:
        return False
    if time.time() - dernier_cycle < DELAI_MIN_S:
        return False
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pin", type=int, default=RELAY_PIN)
    ap.add_argument("--test", action="store_true", help="affiche la décision sans agir")
    args = ap.parse_args()

    relais = Relais(args.pin)
    try:
        if args.test:
            print(f"relais sur GPIO{args.pin}, état actuel = {relais.etat()}")
            return 0
        # Boucle de service : le cœur (publier.py) publie l'état; ici on applique.
        # Dans cette version, la décision est prise par le cœur et publiée sur
        # serre/pompe ; ce programme ne fait qu'exécuter et surveiller.
        print(f"relais GPIO{args.pin} armé — pompe à l'arrêt")
        dernier = 0.0
        while True:
            time.sleep(10)
    except KeyboardInterrupt:
        pass
    finally:
        relais.activer(False)   # ferme sur sortie : la pompe s'arrête
        relais.fermer()
        print("relais désarmé — pompe à l'arrêt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
