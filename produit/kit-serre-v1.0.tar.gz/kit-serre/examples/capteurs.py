#!/usr/bin/env python3
"""Kit serre — lecture des capteurs.

SHT31   (I2C 0x44)  température + humidité relative de l'air
BH1750  (I2C 0x23)  éclairement en lux
ADS1115 (I2C 0x48)  humidité du sol (entrée A0, à étalonner)
DS18B20 (1-Wire)    température du sol

Dépend uniquement de smbus2 (pip install smbus2) et du noyau.
Aucune clé privée, aucun réseau : lectures locales.

Usage :
    python3 capteurs.py          # une mesure
    python3 capteurs.py --json   # une mesure en JSON
    python3 capteurs.py --suivi 5
"""
from __future__ import annotations

import glob
import json
import os
import sys
import time

try:
    import smbus2
except ImportError:  # pragma: no cover
    smbus2 = None

SHT31_ADDR = 0x44
BH1750_ADDR = 0x23
ADS1115_ADDR = 0x48
BUS_NUM = 1

# Étalonnage de la sonde de sol : à mesurer une fois (voir guide §5.3)
SOL_V_AIR = 2.60   # tension mesurée au sec, en volts
SOL_V_EAU = 1.10   # tension mesurée dans l'eau, en volts


def crc8_sensirion(data: bytes) -> int:
    """CRC8 de Sensirion : polynomiale 0x31, initiale 0xFF."""
    crc = 0xFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0x31) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def lire_sht31(bus) -> tuple[float | None, float | None]:
    """Retourne (température °C, humidité %). None si le CRC échoue."""
    try:
        bus.write_i2c_block_data(SHT31_ADDR, 0x24, [0x00])
        time.sleep(0.02)
        d = bus.read_i2c_block_data(SHT31_ADDR, 0x00, 6)
    except OSError:
        return None, None
    if len(d) < 6:
        return None, None
    t_raw = (d[0] << 8) | d[1]
    h_raw = (d[3] << 8) | d[4]
    if crc8_sensirion(bytes(d[0:2])) != d[2] or crc8_sensirion(bytes(d[3:5])) != d[5]:
        return None, None
    temp = -45.0 + 175.0 * (t_raw / 65535.0)
    hum = 100.0 * (h_raw / 65535.0)
    return round(temp, 2), round(min(100.0, max(0.0, hum)), 2)


def lire_bh1750(bus) -> float | None:
    """Retourne l'éclairement en lux (mode haute résolution)."""
    try:
        bus.write_byte(BH1750_ADDR, 0x20)
        time.sleep(0.2)
        d = bus.read_i2c_block_data(BH1750_ADDR, 0x00, 2)
    except OSError:
        return None
    if len(d) < 2:
        return None
    return round(((d[0] << 8) | d[1]) / 1.2, 1)


def lire_ads1115_a0(bus) -> float | None:
    """Retourne la tension (V) sur AIN0, gain ±4,096 V."""
    try:
        bus.write_i2c_block_data(ADS1115_ADDR, 0x01, [0xC3, 0x83])
        time.sleep(0.01)
        raw = bus.read_word_data(ADS1115_ADDR, 0x00)
    except OSError:
        return None
    if raw >= 0x8000:
        raw -= 0x10000
    return round(raw * 0.000125, 4)   # 1 LSB = 4,096 / 32768 = 125 µV


def humidite_sol(tension: float | None) -> float | None:
    if tension is None:
        return None
    if SOL_V_AIR <= SOL_V_EAU:
        return None
    pct = 100.0 * (SOL_V_AIR - tension) / (SOL_V_AIR - SOL_V_EAU)
    return round(min(100.0, max(0.0, pct)), 1)


def lire_ds18b20() -> float | None:
    """Retourne la température du sol en °C, ou None si absente/invalid."""
    roms = [p for p in glob.glob("/sys/bus/w1/devices/28-*")]
    if not roms:
        return None
    try:
        txt = open(os.path.join(roms[0], "w1_slave")).read()
    except OSError:
        return None
    if "YES" not in txt:
        return None
    for line in txt.splitlines():
        if "t=" in line:
            try:
                return round(int(line.split("t=")[1]) / 1000.0, 2)
            except ValueError:
                return None
    return None


def mesurer() -> dict:
    out: dict = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S")}
    if smbus2 is None:
        return {"erreur": "smbus2 absent (pip install smbus2)"}
    try:
        bus = smbus2.SMBus(BUS_NUM)
    except OSError as exc:
        return {"erreur": f"bus I2C indisponible : {exc}"}
    try:
        t, h = lire_sht31(bus)
        out["air_temperature"] = t
        out["air_humidite"] = h
        out["lux"] = lire_bh1750(bus)
        v = lire_ads1115_a0(bus)
        out["sol_tension"] = v
        out["sol_humidite"] = humidite_sol(v)
    finally:
        bus.close()
    out["sol_temperature"] = lire_ds18b20()
    return out


def main() -> int:
    args = sys.argv[1:]
    if "--json" in args:
        print(json.dumps(mesurer(), ensure_ascii=False))
        return 0
    if "--suivi" in args:
        i = args.index("--suivi")
        periode = float(args[i + 1]) if len(args) > i + 1 else 5.0
        while True:
            m = mesurer()
            print(json.dumps(m, ensure_ascii=False), flush=True)
            time.sleep(periode)
    m = mesurer()
    if "erreur" in m:
        print("ERREUR :", m["erreur"])
        return 1
    print(f"air        {m.get('air_temperature')} °C   {m.get('air_humidite')} %")
    print(f"lumière    {m.get('lux')} lux")
    print(f"sol        {m.get('sol_humidite')} %     {m.get('sol_temperature')} °C")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
