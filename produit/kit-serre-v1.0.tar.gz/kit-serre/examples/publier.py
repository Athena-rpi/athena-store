#!/usr/bin/env python3
"""Kit serre — publie les mesures sur MQTT (mosquitto_pub).

Aucune bibliothèque MQTT : on appelle l'outil mosquitto_pub, ce qui rend le
script trivial à déboguer (la commande exacte est affichée).

Usage :
    python3 publier.py --suivi 60      # publie toutes les 60 s
    python3 publier.py                 # une fois
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time

import capteurs

HOST = "127.0.0.1"
TOPICS = {
    "air_temperature": "serre/air/temperature",
    "air_humidite": "serre/air/humidite",
    "lux": "serre/lux",
    "sol_humidite": "serre/sol/humidite",
    "sol_temperature": "serre/sol/temperature",
}


def publier(cle: str, valeur, retain: bool = True) -> bool:
    topic = TOPICS.get(cle)
    if topic is None or valeur is None:
        return False
    if shutil.which("mosquitto_pub") is None:
        print("mosquitto_pub introuvable — installer mosquitto-clients", file=sys.stderr)
        return False
    cmd = ["mosquitto_pub", "-h", HOST, "-t", topic, "-m", str(valeur)]
    if retain:
        cmd.append("-r")
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"échec {topic} : {r.stderr.strip()}", file=sys.stderr)
        return False
    print(f"{topic} = {valeur}")
    return True


def un_cycle() -> int:
    m = capteurs.mesurer()
    if "erreur" in m:
        print("ERREUR :", m["erreur"], file=sys.stderr)
        return 1
    ok = 0
    for cle in TOPICS:
        if publier(cle, m.get(cle)):
            ok += 1
    print(f"{ok} mesure(s) publiée(s) — {m['ts']}")
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--suivi", type=float, metavar="SECONDES", help="période de publication")
    args = ap.parse_args()
    if args.suivi:
        while True:
            un_cycle()
            time.sleep(args.suivi)
    return un_cycle()


if __name__ == "__main__":
    raise SystemExit(main())
