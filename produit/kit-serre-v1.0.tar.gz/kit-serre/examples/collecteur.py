#!/usr/bin/env python3
"""Kit serre — collecteur MQTT vers SQLite.

Écoute `serre/#` et écrit chaque valeur dans SQLite, après rejet des valeurs
manifestement aberrantes. Une sonde déconnectée renvoie souvent 0 ou une valeur
extrême : mieux vaut ne rien écrire qu'écrire un faux.

Dépend uniquement de mosquitto_sub (paquet mosquitto-clients).

Usage :
    python3 collecteur.py                            # serre.db au courant
    python3 collecteur.py --base /var/lib/serre.db
"""
from __future__ import annotations

import argparse
import sqlite3
import subprocess
import sys
import time

PLAGES: dict[str, tuple[float, float]] = {
    "serre/air/temperature": (-10.0, 60.0),
    "serre/air/humidite": (0.0, 100.0),
    "serre/lux": (0.0, 120000.0),
    "serre/sol/humidite": (0.0, 100.0),
    "serre/sol/temperature": (-10.0, 60.0),
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS mesures (
    ts      TEXT NOT NULL,
    capteur TEXT NOT NULL,
    valeur  REAL NOT NULL,
    unite   TEXT,
    PRIMARY KEY (ts, capteur)
);
CREATE INDEX IF NOT EXISTS idx_mesures_capteur ON mesures(capteur, ts);
"""


def ouvrir(base: str) -> sqlite3.Connection:
    con = sqlite3.connect(base)
    con.executescript(SCHEMA)
    return con


def inserer(con: sqlite3.Connection, topic: str, valeur: float, unite: str) -> bool:
    plage = PLAGES.get(topic)
    if plage is None:
        return False
    bas, haut = plage
    if not (bas <= valeur <= haut):
        print(f"rejeté (hors plage {bas}..{haut}) : {topic} = {valeur}", file=sys.stderr)
        return False
    con.execute(
        "INSERT OR REPLACE INTO mesures (ts, capteur, valeur, unite) VALUES (?,?,?,?)",
        (time.strftime("%Y-%m-%dT%H:%M:%S"), topic, valeur, unite),
    )
    con.commit()
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="serre.db")
    ap.add_argument("--hote", default="127.0.0.1")
    args = ap.parse_args()

    con = ouvrir(args.base)
    print(f"collecteur sur serre/# → {args.base}", flush=True)
    proc = subprocess.Popen(
        ["mosquitto_sub", "-h", args.hote, "-t", "serre/#", "-v"],
        stdout=subprocess.PIPE, text=True,
    )
    try:
        for ligne in proc.stdout:
            ligne = ligne.strip()
            if not ligne or " " not in ligne:
                continue
            topic, _, valeur = ligne.partition(" ")
            if topic not in PLAGES:
                continue
            try:
                v = float(valeur)
            except ValueError:
                print(f"rejeté (non numérique) : {topic} = {valeur}", file=sys.stderr)
                continue
            inserer(con, topic, v, "")
    except KeyboardInterrupt:
        pass
    finally:
        proc.terminate()
        con.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
