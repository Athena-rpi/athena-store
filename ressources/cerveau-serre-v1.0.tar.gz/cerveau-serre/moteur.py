#!/usr/bin/env python3
"""Cerveau de serre — moteur de décision d'arrosage, sans matériel.

Module autonome, stdlib uniquement. Aucun pilote, aucun fichier ouvert, aucun
état matériel écrit, aucun effet de bord à l'import.

Entrées : humidité du sol (%), état de la cuve, instant, date du dernier cycle,
configuration, état d'hystérésis. Sortie : une `Decision` figée (décision,
motif, détail, alerte éventuelle, état d'hystérésis suivant).

Règle nominale (reprise de kit-serre/examples/arrosage.py) :
    arroser si sol < seuil_sec (25 %) et cuve pleine et
    heure_debut <= heure < heure_fin ([6 h, 21 h[) et
    maintenant - dernier_cycle >= delai_min_s (600 s). Durée : 30 s.

Hystérésis (amélioration spécifiée dans le cahier des charges §4.1) : après un
cycle déclenché, un nouveau cycle est bloqué jusqu'à ce que le sol remonte à
seuil_sec + marge (25 + 5 = 30 %). L'état est explicite, jamais caché dans une
variable globale : la fonction reste pure.

Défaut sûr : donnée absente, NaN/infini, hors plage, cuve inconnue, horodatage
incohérent ou configuration incomplète => pas d'arrosage, motif
`donnee_invalide` et alerte. Aucune valeur par défaut « favorable ».

Ordre d'évaluation des motifs (le premier bloquant gagne) :
    donnee_invalide, cuve_vide, hors_fenetre, hysterese, sol_humide, delai, ok

`dernier_cycle` accepte un datetime ou un timestamp NTP/epoch en secondes ;
`None` signifie « aucun cycle jusqu'ici » (délai considéré écoulé). Les deux
horodatages doivent être du même type (naïfs ou conscients de leur fuseau).

Limites non couvertes : câblage, étalonnage réel d'une sonde, sécurité
électrique d'un relais, météo et agronomie. Ce module ne mesure rien.
"""
from __future__ import annotations

import datetime as _dt
import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, cast

__all__ = ["Config", "Decision", "MOTIFS", "decider"]

MOTIFS = (
    "donnee_invalide",
    "cuve_vide",
    "hors_fenetre",
    "hysterese",
    "sol_humide",
    "delai",
    "ok",
)

_CHAMPS = (
    "seuil_sec",
    "duree_s",
    "delai_min_s",
    "heure_debut",
    "heure_fin",
    "marge_hysterese",
)


def _nombre(valeur: object, nom: str) -> float:
    """Valide un nombre réel fini, en refusant les booléens."""
    if isinstance(valeur, bool) or not isinstance(valeur, (int, float)):
        raise ValueError(f"{nom} doit être un nombre")
    try:
        v = float(valeur)
    except (OverflowError, ValueError, TypeError) as exc:
        raise ValueError(f"{nom} n'est pas convertible") from exc
    if not math.isfinite(v):
        raise ValueError(f"{nom} doit être fini")
    return v


def _sol(valeur: object) -> float:
    """Humidité du sol : nombre fini dans [0, 100], sinon défaut sûr."""
    v = _nombre(valeur, "sol")
    if not 0.0 <= v <= 100.0:
        raise ValueError("sol hors de [0, 100]")
    return v


@dataclass(frozen=True)
class Config:
    """Configuration validée à la construction ; bornes documentées."""

    seuil_sec: float = 25.0
    duree_s: int = 30
    delai_min_s: int = 600
    heure_debut: int = 6
    heure_fin: int = 21
    marge_hysterese: float = 5.0

    def __post_init__(self) -> None:
        seuil = _nombre(self.seuil_sec, "seuil_sec")
        duree = _nombre(self.duree_s, "duree_s")
        delai = _nombre(self.delai_min_s, "delai_min_s")
        debut = _nombre(self.heure_debut, "heure_debut")
        fin = _nombre(self.heure_fin, "heure_fin")
        marge = _nombre(self.marge_hysterese, "marge_hysterese")
        if not 0.0 <= seuil <= 100.0:
            raise ValueError("seuil_sec hors de [0, 100]")
        if not 0.0 < duree <= 3600.0:
            raise ValueError("duree_s hors de (0, 3600]")
        if not 0.0 <= delai <= 86400.0:
            raise ValueError("delai_min_s hors de [0, 86400]")
        if not 0 <= debut < fin <= 24:
            raise ValueError("fenêtre horaire invalide")
        if not 0.0 <= marge <= 100.0:
            raise ValueError("marge_hysterese hors de [0, 100]")
        if seuil + marge > 100.0:
            raise ValueError("seuil_sec + marge_hysterese dépasse 100 % : réarmement impossible")


@dataclass(frozen=True)
class Decision:
    """Résultat figé et horodaté d'une évaluation du moteur."""

    arroser: bool
    motif: str
    detail: str
    alerte: str | None
    etat_hysterese: bool
    duree_s: int
    horodatage: str


def _config(config: Config | Mapping[str, object] | None) -> Config:
    if config is None:
        return Config()
    if isinstance(config, Config):
        return config
    if isinstance(config, Mapping):
        manquantes = [c for c in _CHAMPS if c not in config]
        if manquantes:
            raise ValueError("clés manquantes : " + ", ".join(manquantes))
        try:
            return Config(**cast(dict[str, Any], {c: config[c] for c in _CHAMPS}))
        except TypeError as exc:
            raise ValueError(f"configuration invalide : {exc}") from exc
    raise ValueError("configuration ni Config ni dictionnaire")


def _timestamp(valeur: object, maintenant: _dt.datetime) -> float:
    if valeur is None:
        return -math.inf                    # aucun cycle : délai écoulé
    if isinstance(valeur, bool):
        raise ValueError("horodatage booléen")
    if isinstance(valeur, (int, float)):
        ts = _nombre(valeur, "dernier_cycle")
        if ts < 0:
            raise ValueError("horodatage négatif")
        return ts
    if isinstance(valeur, _dt.datetime):
        if (valeur.tzinfo is None) != (maintenant.tzinfo is None):
            raise ValueError("horodatages naïf et conscient mélangés")
        return valeur.timestamp()
    raise ValueError("horodatage d'un type inattendu")


def _refus(motif: str, detail: str, maintenant: _dt.datetime,
           etat: bool = False, alerte: str | None = None) -> Decision:
    return Decision(
        arroser=False,
        motif=motif,
        detail=detail,
        alerte=alerte,
        etat_hysterese=etat,
        duree_s=0,
        horodatage=maintenant.isoformat(timespec="seconds"),
    )


def decider(
    sol: float | None,
    cuve_pleine: bool | None,
    maintenant: _dt.datetime | None = None,
    dernier_cycle: _dt.datetime | float | None = None,
    config: Config | Mapping[str, object] | None = None,
    en_hysterese: bool = False,
) -> Decision:
    """Décide d'un arrosage. Fonction pure : aucun état global, aucun I/O.

    `maintenant=None` prend l'heure locale réelle ; tous les tests et le
    simulateur doivent fournir un instant explicite pour être déterministes.
    """
    instant_ref = maintenant if isinstance(maintenant, _dt.datetime) else _dt.datetime.now()
    try:
        cfg = _config(config)
    except (TypeError, ValueError, OverflowError) as exc:
        return _refus("donnee_invalide", f"configuration invalide : {exc}",
                      instant_ref, alerte=f"configuration invalide : {exc}")

    if maintenant is None:
        maintenant = _dt.datetime.now()
    if not isinstance(maintenant, _dt.datetime):
        return _refus("donnee_invalide", "instant d'évaluation invalide",
                      _dt.datetime.now(), alerte="horodatage : donnée invalide")
    if not isinstance(en_hysterese, bool):
        return _refus("donnee_invalide", "état d'hystérésis invalide",
                      maintenant, alerte="état d'hystérésis : donnée invalide")
    stamp = maintenant.isoformat(timespec="seconds")

    try:
        sol_val = _sol(sol)
    except (TypeError, ValueError, OverflowError):
        return _refus("donnee_invalide", "humidité du sol absente ou hors de [0, 100] %",
                      maintenant, en_hysterese, "capteur sol : donnée invalide")
    if not isinstance(cuve_pleine, bool):
        return _refus("donnee_invalide", "état de la cuve inconnu",
                      maintenant, en_hysterese, "cuve : état inconnu")

    try:
        dernier_ts = _timestamp(dernier_cycle, maintenant)
        ecoule = maintenant.timestamp() - dernier_ts
        if not math.isfinite(ecoule) and ecoule != math.inf:
            raise ValueError("écart de temps non fini")
        if ecoule < 0:
            raise ValueError("dernier cycle dans le futur")
    except (TypeError, ValueError, OverflowError, OSError) as exc:
        return _refus("donnee_invalide", f"horodatage du dernier cycle invalide : {exc}",
                      maintenant, en_hysterese, "horodatage : donnée invalide")

    if not cuve_pleine:
        return _refus("cuve_vide", "cuve vide : arrosage interdit",
                      maintenant, en_hysterese, "cuve vide")
    if not (cfg.heure_debut <= maintenant.hour < cfg.heure_fin):
        return _refus("hors_fenetre",
                      f"heure {maintenant.hour} h hors de [{cfg.heure_debut} h, {cfg.heure_fin} h[",
                      maintenant, en_hysterese)

    seuil_rearmement = cfg.seuil_sec + cfg.marge_hysterese
    if en_hysterese:
        if sol_val < seuil_rearmement:
            return _refus("hysterese",
                          f"cycle précédent : attendre un sol >= {seuil_rearmement:g} % pour réarmer",
                          maintenant, True)

    if sol_val >= cfg.seuil_sec:
        return _refus("sol_humide", f"sol à {sol_val:g} % >= seuil {cfg.seuil_sec:g} %",
                      maintenant, False)

    if ecoule < cfg.delai_min_s:
        return _refus("delai",
                      f"dernier cycle il y a {ecoule:.0f} s < {cfg.delai_min_s:g} s",
                      maintenant, en_hysterese)

    return Decision(
        arroser=True,
        motif="ok",
        detail=(f"sol {sol_val:g} % < {cfg.seuil_sec:g} % ; cuve pleine ; "
                f"{maintenant.hour} h dans la fenêtre ; délai {ecoule:.0f} s"),
        alerte=None,
        etat_hysterese=True,
        duree_s=int(cfg.duree_s),
        horodatage=stamp,
    )
