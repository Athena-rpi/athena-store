# Cerveau de serre — moteur de décision

Lot B7 / tâche T19. Module autonome, **stdlib uniquement**, zéro capteur,
zéro relais, zéro effet de bord à l'import. Voir le cahier des charges :
`store/projets/cerveau-serre/cahier-des-charges.md` §4.1.

## Usage

Depuis la racine du dépôt, avec `importlib` (aucun paquet à installer) :

```python
import datetime, importlib.util, pathlib, sys
p = pathlib.Path("store/products/cerveau-serre/moteur.py")
spec = importlib.util.spec_from_file_location("moteur", p)
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m              # obligatoire pour les dataclasses en 3.13
spec.loader.exec_module(m)

d = m.decider(sol=20.0, cuve_pleine=True,
              maintenant=datetime.datetime(2026, 11, 22, 12, 0),
              dernier_cycle=datetime.datetime(2026, 11, 22, 11, 0))
assert d.arroser and d.motif == "ok"
```

`decider()` retourne une `Decision` figée : `arroser`, `motif`, `detail`,
`alerte`, `etat_hysterese`, `duree_s`, `horodatage`.

## Règle

Arroser si sol < 25 %, cuve pleine, heure dans [6 h, 21 h[, et au moins
600 s depuis le dernier cycle. Durée d'un cycle : 30 s.

Hystérésis : après un cycle, le moteur reste verrouillé (`etat_hysterese=True`)
jusqu'à un retour du sol à 30 % (seuil + marge de 5 points). L'état est passé
en entrée/sortie : la fonction reste pure et déterministe.

Défaut sûr : None, NaN, infini, valeur hors [0, 100], cuve inconnue,
horodatage incohérent ou configuration incomplète → `arroser=False`,
motif `donnee_invalide` et une alerte. Jamais de valeur favorable implicite.

Motifs, par ordre de priorité : `donnee_invalide`, `cuve_vide`,
`hors_fenetre`, `hysterese`, `sol_humide`, `delai`, `ok`.

## Configuration

`Config()` donne les valeurs par défaut du kit. Un dictionnaire doit contenir
les six clés (`seuil_sec`, `duree_s`, `delai_min_s`, `heure_debut`,
`heure_fin`, `marge_hysterese`) ; toute clé manquante ou hors bornes est un
défaut sûr, pas un remplissage silencieux.

## Simulateur (T20)

`simulateur.py` rejoue le moteur sur quatre scénarios **étiquetés** :
`saison_temperee`, `secheresse`, `cuve_vide`, `panne_capteur`. Stdlib uniquement,
aucune donnée réelle, aucun matériel, aucun réseau.

```bash
python3 store/products/cerveau-serre/simulateur.py            # tous les scénarios
python3 store/products/cerveau-serre/simulateur.py --scenario secheresse --pas 1
```

Sorties (CSV + JSON + courbe SVG) dans `store/products/cerveau-serre/sorties/`,
dossier de travail **jamais diffusé ni versionné** (voir `.gitignore`). Chaque
série porte `source: simule`, `scenario`, `graine`, `genere_le` ; toute courbe
affiche « DONNÉES SIMULÉES ».

Graine par défaut `20261122`, pas 60 min. **Reproductibilité** : deux
exécutions avec la même graine donnent des fichiers octet pour octet identiques
(`sha256sum`). Pour cela `genere_le` est dérivé de la graine, jamais de l'heure
murale ; `--horodatage-reel` active l'heure murale et casse cette propriété.
L'arrosage simulé élève l'humidité des 3 pas suivants à 33 % — effet de
modèle, pas une mesure.

## Tests et limites

```bash
python3 -m unittest discover -s store/products/cerveau-serre/tests -v
```

69 tests : moteur (48) + simulateur (21). Ils couvrent la logique pure : règle
nominale, bornes horaires, délai, hystérésis, défauts sûrs, validation de
configuration, pureté, déterminisme, étiquetage et absence de dépendance
matérielle.

Non couvert : câblage, étalonnage réel d'une sonde, sécurité électrique d'un
relais, météo, agronomie. Aucune mesure réelle n'est utilisée ni suggérée.
Rien n'est diffusé : le code reste local, en attente de relecture.

## Tableau de bord local (T21)

`tableau_de_bord.py` sert, sur **127.0.0.1:8082** seulement, un tableau de bord
qui affiche les décisions du jour de référence (24 pas), l'état des réserves
simulées et les alertes. Le CSS est celui de `sys/health_web.py` à l'identique,
plus trois classes propres au bandeau d'avertissement.

```bash
python3 store/products/cerveau-serre/tableau_de_bord.py            # 127.0.0.1:8082
python3 store/products/cerveau-serre/tableau_de_bord.py --port 8097
curl -4 http://127.0.0.1:8082/api/serre
curl -4 'http://127.0.0.1:8082/?scenario=panne_capteur'
```

Les chiffres sont calculés **en mémoire** par `simulateur.produire()` : aucun
fichier n'est lu ni écrit, aucun capteur n'est consulté, aucun actionneur n'est
piloté. Chaque page porte « DONNEES SIMULEES — aucune mesure réelle ». Le
paramètre `?scenario=` est validé contre la liste des quatre scénarios (une
valeur inconnue retombe sur `saison_temperee`). Aucun service systemd n'est
installé : le lancement reste manuel et réversible.

Tests : `python3 -m unittest discover -s store/products/cerveau-serre/tests -v`
→ 80 tests (69 moteur/simulateur + 11 tableau de bord).
