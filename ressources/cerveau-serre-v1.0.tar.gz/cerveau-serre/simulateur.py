#!/usr/bin/env python3
"""Cerveau de serre — simulateur déterministe (lot B7 / tâche T20).

Rejoue le moteur de décision (`moteur.py`) sur des scénarios étiquetés et
produit, pour chaque scénario, un CSV, un JSON et une courbe SVG générée en
stdlib. Aucune donnée réelle, aucun matériel, aucun paquet tiers, aucun effet
de bord à l'import.

Déterminisme (critère d'acceptation §7.2 du cahier des charges) :
    deux exécutions avec la même graine produisent des octets identiques.
    Pour cela, `genere_le` est DÉRIVÉ DE LA GRAINE par défaut (horodatage
    reproductible), jamais l'heure murale. Le drapeau --horodatage-reel active
    l'heure murale, au prix de la reproductibilité octet pour octet.

Les fichiers sont écrits dans un dossier de travail (par défaut
`store/products/cerveau-serre/sorties/`), jamais diffusés automatiquement.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import importlib.util
import io
import json
import math
import pathlib
import random
import sys
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any

RACINE = pathlib.Path(__file__).resolve().parent
REFERENCE = dt.datetime(2026, 11, 22, 0, 0, 0)
GRAINE_DEFAUT = 20261122
PAS_DEFAUT = 60           # minutes (1 h pour les courbes longues)
JOURS_DEFAUT: dict[str, int] = {
    "saison_temperee": 90,
    "secheresse": 30,
    "cuve_vide": 7,
    "panne_capteur": 3,
}

__all__ = [
    "SCENARIOS", "Pas", "Evenement", "charger_moteur", "generer_pas",
    "rejouer", "produire", "ecrire", "simuler",
]

SCENARIOS = ("saison_temperee", "secheresse", "cuve_vide", "panne_capteur")


# --------------------------------------------------------------------------
# Chargement du moteur (même techniques que les tests : importlib + sys.modules)
# --------------------------------------------------------------------------
def charger_moteur():
    """Charge moteur.py depuis le dossier du simulateur, sans effet global."""
    spec = importlib.util.spec_from_file_location("moteur_simule", RACINE / "moteur.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("moteur.py introuvable")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod          # requis par dataclasses sous Python 3.13
    spec.loader.exec_module(mod)
    return mod


# --------------------------------------------------------------------------
# Types de données
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Pas:
    """Un pas de simulation : instant, humidité brute du scénario, état cuve."""

    instant: dt.datetime
    sol: float | None
    cuve_pleine: bool | None


@dataclass(frozen=True)
class Evenement:
    """Une décision du moteur, horodatée, avec sa série d'entrées."""

    instant: dt.datetime
    sol_effectif: float | None
    sol_brut: str
    cuve_pleine: bool | None
    motif: str
    arroser: bool
    alerte: str | None
    etat_hysterese: bool
    duree_s: int


# --------------------------------------------------------------------------
# Générateurs de scénarios (tous pilotés par un random.Random local)
# --------------------------------------------------------------------------
def _saison_temperee(rng: random.Random, debut: dt.datetime, n: int,
                     pas: int) -> list[Pas]:
    """Saison tempérée : cycle jour/nuit, pluies sporadiques, cuve qui se vide."""
    out: list[Pas] = []
    sol = 28.0
    cuve = True
    pas_cuve_vide = 0
    for i in range(n):
        instant = debut + dt.timedelta(minutes=pas * i)
        heure = instant.hour
        if 6 <= heure < 21:
            sol -= rng.uniform(0.35, 1.30)     # évaporation diurne
        else:
            sol += rng.uniform(0.00, 0.55)     # récupération nocturne
        sol += rng.uniform(-0.35, 0.35)
        if rng.random() < 0.015:               # averse
            sol += rng.uniform(8.0, 20.0)
        sol = max(0.0, min(100.0, sol))

        if pas_cuve_vide > 0:
            pas_cuve_vide -= 1
            cuve = False
        elif rng.random() < 0.004:
            cuve = False
            pas_cuve_vide = max(1, int(24 * 60 / pas))   # ~1 jour
        else:
            cuve = True
        out.append(Pas(instant, round(sol, 3), cuve))
    return out


def _secheresse(rng: random.Random, debut: dt.datetime, n: int,
                pas: int) -> list[Pas]:
    """Sécheresse : aucune pluie, sol structuré bas, cuve pleine (irriguée)."""
    out: list[Pas] = []
    sol = 18.0
    for i in range(n):
        instant = debut + dt.timedelta(minutes=pas * i)
        sol -= rng.uniform(0.20, 0.80)
        sol = max(3.0, min(100.0, sol + rng.uniform(-0.25, 0.25)))
        out.append(Pas(instant, round(sol, 3), True))
    return out


def _cuve_vide(rng: random.Random, debut: dt.datetime, n: int,
               pas: int) -> list[Pas]:
    """Cuve vide : sol sec, réserve à zéro en permanence → aucun arrosage."""
    out: list[Pas] = []
    sol = 12.0
    for i in range(n):
        instant = debut + dt.timedelta(minutes=pas * i)
        sol = max(2.0, min(100.0, sol + rng.uniform(-1.0, 1.0)))
        out.append(Pas(instant, round(sol, 3), False))
    return out


def _panne_capteur(rng: random.Random, debut: dt.datetime, n: int,
                   pas: int) -> list[Pas]:
    """Panne capteur : None, NaN, hors plage et valeurs plausibles mêlés."""
    out: list[Pas] = []
    for i in range(n):
        instant = debut + dt.timedelta(minutes=pas * i)
        r = rng.random()
        if r < 0.10:
            sol: float | None = None           # absent
        elif r < 0.20:
            sol = math.nan                     # aberrant
        elif r < 0.30:
            sol = 150.0                        # hors plage
        else:
            sol = round(rng.uniform(15.0, 28.0), 3)
        out.append(Pas(instant, sol, True))
    return out


_GENERATEURS: dict[str, Callable[[random.Random, dt.datetime, int, int], list[Pas]]] = {
    "saison_temperee": _saison_temperee,
    "secheresse": _secheresse,
    "cuve_vide": _cuve_vide,
    "panne_capteur": _panne_capteur,
}


def generer_pas(scenario: str, graine: int, debut: dt.datetime, n: int,
                pas: int) -> list[Pas]:
    """Produit la série de pas d'un scénario, de façon reproductible."""
    if scenario not in _GENERATEURS:
        raise ValueError(f"scénario inconnu : {scenario}")
    if n < 1:
        raise ValueError("nombre de pas < 1")
    if pas < 1:
        raise ValueError("pas < 1 minute")
    rng = random.Random(graine)          # graine locale : jamais random global
    return _GENERATEURS[scenario](rng, debut, n, pas)


# --------------------------------------------------------------------------
# Rejeu du moteur
# --------------------------------------------------------------------------
def _sol_json(sol: float | None) -> float | None:
    """Valeur sûre pour JSON : non fini / hors plage -> None."""
    if sol is None:
        return None
    if not isinstance(sol, (int, float)) or isinstance(sol, bool):
        return None
    v = float(sol)
    if not math.isfinite(v) or not 0.0 <= v <= 100.0:
        return None
    return round(v, 3)


def _sol_brut(sol: float | None) -> str:
    """Représentation textuelle déterministe de la valeur brute du scénario."""
    if sol is None:
        return "absent"
    if isinstance(sol, float) and math.isnan(sol):
        return "nan"
    if isinstance(sol, float) and math.isinf(sol):
        return "infini"
    return str(sol)


def rejouer(pas_series: Sequence[Pas], moteur, config=None) -> list[Evenement]:
    """Rejoue moteur.decider pas à pas, en chaînant hystérésis et dernier cycle.

    Un arrosage simulé élève l'humidité des 3 pas suivants à 33 % (capacité au
    champ), ce qui désarme l'hystérésis et rend visibles les cycles sur courbe.
    Cet effet est une donnée SIMULÉE, pas une mesure.
    """
    evenements: list[Evenement] = []
    en_hysterese = False
    dernier_cycle: dt.datetime | None = None
    pas_humides = 0

    for p in pas_series:
        brut = p.sol
        if pas_humides > 0:
            effectif: float | None = 33.0
            pas_humides -= 1
        else:
            effectif = brut

        d = moteur.decider(
            sol=effectif,
            cuve_pleine=p.cuve_pleine,
            maintenant=p.instant,
            dernier_cycle=dernier_cycle,
            config=config,
            en_hysterese=en_hysterese,
        )
        en_hysterese = d.etat_hysterese
        if d.arroser:
            dernier_cycle = p.instant
            pas_humides = 3

        evenements.append(Evenement(
            instant=p.instant,
            sol_effectif=_sol_json(effectif),
            sol_brut=_sol_brut(brut),
            cuve_pleine=p.cuve_pleine,
            motif=d.motif,
            arroser=d.arroser,
            alerte=d.alerte,
            etat_hysterese=d.etat_hysterese,
            duree_s=d.duree_s,
        ))
    return evenements


# --------------------------------------------------------------------------
# Métadonnées et séries
# --------------------------------------------------------------------------
def _horodatage(graine: int, reel: bool) -> str:
    if reel:
        return dt.datetime.now().isoformat(timespec="seconds")
    # Reproductible : heure de la date de référence, dérivée de la graine.
    return (REFERENCE + dt.timedelta(seconds=graine % 86400)).isoformat(timespec="seconds")


def _configuration(moteur) -> dict[str, Any]:
    cfg = moteur.Config()
    return {
        "seuil_sec": cfg.seuil_sec,
        "duree_s": cfg.duree_s,
        "delai_min_s": cfg.delai_min_s,
        "heure_debut": cfg.heure_debut,
        "heure_fin": cfg.heure_fin,
        "marge_hysterese": cfg.marge_hysterese,
    }


def _resume(evenements: Sequence[Evenement]) -> dict[str, Any]:
    motifs: dict[str, int] = {}
    for e in evenements:
        motifs[e.motif] = motifs.get(e.motif, 0) + 1
    return {
        "pas": len(evenements),
        "arrosages": sum(1 for e in evenements if e.arroser),
        "alertes": sum(1 for e in evenements if e.alerte is not None),
        "motifs": dict(sorted(motifs.items())),
    }


def _json_doc(scenario: str, graine: int, genere_le: str, reel: bool,
              pas: int, jours: int, moteur, evenements: Sequence[Evenement]) -> str:
    series = []
    for e in evenements:
        series.append({
            "instant": e.instant.isoformat(timespec="seconds"),
            "sol": e.sol_effectif,
            "sol_brut": e.sol_brut,
            "cuve_pleine": e.cuve_pleine,
            "motif": e.motif,
            "arroser": e.arroser,
            "alerte": e.alerte,
            "etat_hysterese": e.etat_hysterese,
            "duree_s": e.duree_s,
        })
    doc = {
        "source": "simule",
        "scenario": scenario,
        "graine": graine,
        "genere_le": genere_le,
        "genere_le_mode": "reel" if reel else "deterministe",
        "avertissement": "DONNEES SIMULEES — aucune mesure réelle",
        "pas_minutes": pas,
        "jours": jours,
        "configuration": _configuration(moteur),
        "resume": _resume(evenements),
        "series": series,
    }
    return json.dumps(doc, ensure_ascii=False, sort_keys=True, indent=2,
                      allow_nan=False) + "\n"


_COLONNES = ("source", "scenario", "graine", "instant", "sol", "sol_brut",
             "cuve_pleine", "motif", "arroser", "alerte", "etat_hysterese",
             "duree_s")


def _csv_doc(scenario: str, graine: int, evenements: Sequence[Evenement]) -> str:
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(_COLONNES)
    for e in evenements:
        w.writerow((
            "simule", scenario, graine,
            e.instant.isoformat(timespec="seconds"),
            "" if e.sol_effectif is None else e.sol_effectif,
            e.sol_brut,
            "" if e.cuve_pleine is None else e.cuve_pleine,
            e.motif, e.arroser, e.alerte or "", e.etat_hysterese, e.duree_s,
        ))
    return buf.getvalue()


def _echapper(texte: str) -> str:
    return (texte.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _svg_doc(scenario: str, graine: int, genere_le: str,
             evenements: Sequence[Evenement]) -> str:
    """Courbe SVG pure stdlib : humidité effective + points d'arrosage."""
    L, H = 760, 340
    G = 52                      # marge gauche / droite
    H_haut, H_bas = 46, 286     # marge haut / bas
    largeur = L - 2 * G
    hauteur = H_bas - H_haut
    n = max(1, len(evenements) - 1)

    def xy(i: int, sol: float) -> tuple[float, float]:
        x = G + (largeur * i / n)
        y = H_bas - (hauteur * (max(0.0, min(100.0, sol)) / 100.0))
        return (x, y)

    parts: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{L}" height="{H}" '
        f'viewBox="0 0 {L} {H}" role="img">',
        f'<rect x="0" y="0" width="{L}" height="{H}" fill="#fbfbf8"/>',
        f'<text x="{G}" y="26" font-family="monospace" font-size="15" '
        f'font-weight="bold" fill="#7a1010">DONNÉES SIMULÉES</text>',
    ]
    # Grille et graduations
    for val in (0, 25, 50, 75, 100):
        _, y = xy(0, val)
        parts.append(f'<line x1="{G}" y1="{y:.2f}" x2="{L-G}" y2="{y:.2f}" '
                     f'stroke="#dddddd" stroke-width="1"/>')
        parts.append(f'<text x="{G-8}" y="{y+4:.2f}" font-family="monospace" '
                     f'font-size="10" fill="#555" text-anchor="end">{val}%</text>')
    # Polyligne : on interrompt la courbe sur les points invalides.
    segments: list[str] = []
    courant: list[str] = []
    for i, e in enumerate(evenements):
        if e.sol_effectif is None:
            if len(courant) > 1:
                segments.append(" ".join(courant))
            courant = []
            continue
        x, y = xy(i, e.sol_effectif)
        courant.append(f"{'M' if not courant else 'L'}{x:.2f},{y:.2f}")
    if len(courant) > 1:
        segments.append(" ".join(courant))
    for seg in segments:
        parts.append(f'<path d="{seg}" fill="none" stroke="#1b5e20" '
                     f'stroke-width="1.6"/>')
    # Points d'arrosage simulé
    for i, e in enumerate(evenements):
        if e.arroser:
            x, y = xy(i, e.sol_effectif if e.sol_effectif is not None else 0.0)
            parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3" '
                         f'fill="#1565c0"/>')
    # Légende et métadonnées
    bas = H - 12
    parts += [
        f'<circle cx="{G+6}" cy="{bas-4}" r="3" fill="#1565c0"/>',
        f'<text x="{G+16}" y="{bas}" font-family="monospace" font-size="10" '
        f'fill="#333">arrosage simulé</text>',
        f'<text x="{L-G}" y="{bas}" font-family="monospace" font-size="10" '
        f'fill="#333" text-anchor="end">'
        f'{_echapper(scenario)} · graine {graine} · {_echapper(genere_le)}</text>',
        f'<text x="{G}" y="{H_haut-14}" font-family="monospace" font-size="10" '
        f'fill="#555">humidité du sol (%) — source: simule</text>',
        "</svg>\n",
    ]
    return "\n".join(parts)


def produire(scenario: str, graine: int = GRAINE_DEFAUT, pas: int = PAS_DEFAUT,
             jours: int | None = None, reel: bool = False,
             debut: dt.datetime | None = None) -> dict[str, str]:
    """Retourne {nom_fichier: contenu} pour un scénario. Sans écriture disque."""
    if scenario not in SCENARIOS:
        raise ValueError(f"scénario inconnu : {scenario}")
    if graine < 0:
        raise ValueError("graine négative")
    moteur = charger_moteur()
    jours = JOURS_DEFAUT[scenario] if jours is None else jours
    if jours < 1:
        raise ValueError("jours < 1")
    debut = debut or REFERENCE
    n = max(1, int(jours * 24 * 60 / pas))
    pas_series = generer_pas(scenario, graine, debut, n, pas)
    evenements = rejouer(pas_series, moteur)
    genere_le = _horodatage(graine, reel)
    stem = f"serre_{scenario}_g{graine}"
    return {
        f"{stem}.csv": _csv_doc(scenario, graine, evenements),
        f"{stem}.json": _json_doc(scenario, graine, genere_le, reel, pas, jours,
                                  moteur, evenements),
        f"{stem}.svg": _svg_doc(scenario, graine, genere_le, evenements),
    }


def ecrire(fichiers: dict[str, str], dossier: pathlib.Path) -> list[pathlib.Path]:
    """Écrit les fichiers dans un dossier de travail (créé si besoin)."""
    dossier.mkdir(parents=True, exist_ok=True)
    ecrits = []
    for nom, contenu in fichiers.items():
        p = dossier / nom
        p.write_text(contenu, encoding="utf-8", newline="")
        ecrits.append(p)
    return ecrits


def simuler(scenarios: Sequence[str] = SCENARIOS, graine: int = GRAINE_DEFAUT,
            pas: int = PAS_DEFAUT, dossier: pathlib.Path | None = None,
            reel: bool = False, jours: dict[str, int] | None = None
            ) -> list[pathlib.Path]:
    """Produit et écrit tous les scénarios ; retourne la liste des fichiers."""
    dossier = dossier or (RACINE / "sorties")
    jours = jours or {}
    ecrits: list[pathlib.Path] = []
    for scenario in scenarios:
        fichiers = produire(
            scenario, graine=graine, pas=pas,
            jours=jours.get(scenario), reel=reel,
        )
        ecrits.extend(ecrire(fichiers, dossier))
    return ecrits


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Simulateur déterministe du cerveau de serre")
    ap.add_argument("--scenario", choices=SCENARIOS, action="append",
                    help="scénario à produire (répétable ; défaut : tous)")
    ap.add_argument("--graine", type=int, default=GRAINE_DEFAUT)
    ap.add_argument("--pas", type=int, default=PAS_DEFAUT,
                    help="pas en minutes (défaut 60)")
    ap.add_argument("--jours", type=int, default=None,
                    help="durée en jours (défaut : par scénario)")
    ap.add_argument("--sortie", type=pathlib.Path, default=RACINE / "sorties",
                    help="dossier de travail (jamais diffusé automatiquement)")
    ap.add_argument("--horodatage-reel", action="store_true",
                    help="heure murale (casse la reproductibilité octet pour octet)")
    args = ap.parse_args(argv)

    scenarios = args.scenario or list(SCENARIOS)
    jours = ({s: args.jours for s in scenarios} if args.jours is not None else {})
    ecrits = simuler(scenarios, graine=args.graine, pas=args.pas,
                     dossier=args.sortie, reel=args.horodatage_reel, jours=jours)
    for p in ecrits:
        print(p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
