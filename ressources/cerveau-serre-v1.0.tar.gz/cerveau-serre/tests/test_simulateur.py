#!/usr/bin/env python3
"""Tests du simulateur déterministe du cerveau de serre (T20).

 stdlib uniquement :
    python3 -m unittest discover -s store/products/cerveau-serre/tests -v

Aucun matériel, aucune donnée réelle, aucun paquet tiers, aucun réseau.
"""
from __future__ import annotations

import ast
import datetime as dt
import hashlib
import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest

RACINE = pathlib.Path(__file__).resolve().parent.parent


def _charger(nom: str, fichier: str):
    spec = importlib.util.spec_from_file_location(nom, RACINE / fichier)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod          # dataclasses sous Python 3.13
    spec.loader.exec_module(mod)
    return mod


S = _charger("simulateur_sous_test", "simulateur.py")


def _sha(texte: str) -> str:
    return hashlib.sha256(texte.encode("utf-8")).hexdigest()


class TestDeterminisme(unittest.TestCase):
    """Deux exécutions avec la même graine -> octets identiques (§7.2)."""

    def test_scenarios_deterministes(self):
        for scenario in S.SCENARIOS:
            a = S.produire(scenario)
            b = S.produire(scenario)
            self.assertEqual(set(a), set(b))
            for nom in a:
                self.assertEqual(_sha(a[nom]), _sha(b[nom]),
                                 f"{scenario}/{nom} non reproductible")

    def test_graine_differente_change_les_octets(self):
        a = S.produire("secheresse", graine=1)
        b = S.produire("secheresse", graine=2)
        self.assertNotEqual(_sha(a["serre_secheresse_g1.json"]),
                            _sha(b["serre_secheresse_g2.json"]))

    def test_genere_le_est_derivable_pas_heure_murale(self):
        a = S.produire("cuve_vide", graine=7)
        self.assertEqual(json.loads(a["serre_cuve_vide_g7.json"])["genere_le"],
                         "2026-11-22T00:00:07")
        self.assertEqual(json.loads(a["serre_cuve_vide_g7.json"])["genere_le_mode"],
                         "deterministe")

    def test_deux_ecritures_sur_disque_identiques(self):
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            p1 = S.ecrire(S.produire("panne_capteur", graine=42, jours=1), pathlib.Path(d1))
            p2 = S.ecrire(S.produire("panne_capteur", graine=42, jours=1), pathlib.Path(d2))
            self.assertEqual([p.name for p in p1], [p.name for p in p2])
            for x, y in zip(p1, p2):
                self.assertEqual(x.read_bytes(), y.read_bytes(), x.name)


class TestEtiquetage(unittest.TestCase):
    """Chaque série porte source/scenario/graine ; courbe étiquetée."""

    def test_json_etiquete(self):
        for scenario in S.SCENARIOS:
            doc = json.loads(S.produire(scenario)["serre_" + scenario + "_g20261122.json"])
            self.assertEqual(doc["source"], "simule")
            self.assertEqual(doc["scenario"], scenario)
            self.assertEqual(doc["graine"], S.GRAINE_DEFAUT)
            self.assertIn("genere_le", doc)
            self.assertIn("SIMULE", doc["avertissement"])

    def test_csv_etiquete_a_chaque_ligne(self):
        contenu = S.produire("cuve_vide", graine=5)["serre_cuve_vide_g5.csv"]
        lignes = contenu.splitlines()
        self.assertEqual(lignes[0].split(",")[:3], ["source", "scenario", "graine"])
        self.assertTrue(lignes[1].startswith("simule,cuve_vide,5,"))

    def test_svg_etiquete_et_visible(self):
        svg = S.produire("secheresse")["serre_secheresse_g20261122.svg"]
        self.assertIn("DONNÉES SIMULÉES", svg)
        self.assertIn("source: simule", svg)
        self.assertTrue(svg.lstrip().startswith("<svg"))
        self.assertTrue(svg.rstrip().endswith("</svg>"))

    def test_svg_est_xml_bien_forme(self):
        import xml.etree.ElementTree as ET
        for scenario in S.SCENARIOS:
            svg = S.produire(scenario)["serre_" + scenario + "_g20261122.svg"]
            ET.fromstring(svg)


class TestScenarios(unittest.TestCase):
    """Les quatre scénarios du cahier des charges sont livrés et distincts."""

    def test_quatre_scenarios_livres(self):
        self.assertEqual(set(S.SCENARIOS), {
            "saison_temperee", "secheresse", "cuve_vide", "panne_capteur"})

    def resume(self, scenario, **kw):
        doc = json.loads(S.produire(scenario, **kw)["serre_" + scenario +
                                    "_g" + str(kw.get("graine", S.GRAINE_DEFAUT)) + ".json"])
        return doc["resume"]

    def test_secheresse_arrose(self):
        self.assertGreater(self.resume("secheresse")["arrosages"], 0)

    def test_saison_temperee_arrose(self):
        self.assertGreater(self.resume("saison_temperee")["arrosages"], 0)

    def test_cuve_vide_n_arrosera_jamais(self):
        r = self.resume("cuve_vide")
        self.assertEqual(r["arrosages"], 0)
        self.assertEqual(r["motifs"], {"cuve_vide": r["pas"]})

    def test_panne_capteur_produit_donnee_invalide(self):
        r = self.resume("panne_capteur")
        self.assertGreater(r["motifs"].get("donnee_invalide", 0), 0)

    def test_hysterese_visible_dans_secheresse(self):
        r = self.resume("secheresse")
        self.assertGreater(r["motifs"].get("sol_humide", 0), 0)
        self.assertLess(r["arrosages"], r["pas"])   # pas d'arrosage à chaque pas


class TestRejeuMoteur(unittest.TestCase):
    """Le simulateur appelle réellement moteur.decider, sans le réimplémenter."""

    def test_decision_identique_au_moteur(self):
        m = S.charger_moteur()
        debut = dt.datetime(2026, 11, 22, 12, 0)
        s = [S.Pas(debut, 20.0, True), S.Pas(debut + dt.timedelta(hours=1), 31.0, True)]
        ev = S.rejouer(s, m)
        self.assertTrue(ev[0].arroser)
        self.assertEqual(ev[0].motif, m.decider(20.0, True, debut).motif)
        self.assertEqual(ev[0].duree_s, 30)

    def test_arrosage_suivi_rearme_hysterese(self):
        m = S.charger_moteur()
        debut = dt.datetime(2026, 11, 22, 12, 0)
        p = [S.Pas(debut + dt.timedelta(hours=i), 10.0, True) for i in range(6)]
        ev = S.rejouer(p, m)
        self.assertTrue(ev[0].arroser)
        self.assertEqual(ev[1].motif, "sol_humide")     # sol simulé à 33 %
        self.assertFalse(ev[1].etat_hysterese)          # réarmement

    def test_invalide_passe_au_moteur(self):
        m = S.charger_moteur()
        debut = dt.datetime(2026, 11, 22, 12, 0)
        ev = S.rejouer([S.Pas(debut, math_nan(), True)], m)
        self.assertEqual(ev[0].motif, "donnee_invalide")
        self.assertIsNotNone(ev[0].alerte)


class TestPerimetre(unittest.TestCase):
    """Stdlib uniquement, aucun matériel, aucun réseau, aucun effet de bord."""

    IMPORTS_OK = {"__future__", "argparse", "collections", "csv", "dataclasses",
                  "datetime", "hashlib", "io", "importlib", "json", "math",
                  "pathlib", "random", "sys", "tempfile", "typing",
                  "xml", "unittest"}
    # Concaténés pour que le grep d'acceptation reste muet sur le cœur du
    # produit : ce sont des mots cherchés, pas des imports.
    INTERDITS = ("lg" + "pio", "smbus" + "2", "GP" + "IO", "pa" + "ho",
                 "requests", "urllib", "socket", "http.client")

    def test_imports_stdlib_sans_materiel(self):
        arbre = ast.parse((RACINE / "simulateur.py").read_text(encoding="utf-8"))
        for noeud in ast.walk(arbre):
            if isinstance(noeud, ast.Import):
                for a in noeud.names:
                    self.assertIn(a.name.split(".")[0], self.IMPORTS_OK, a.name)
            elif isinstance(noeud, ast.ImportFrom):
                self.assertIn((noeud.module or "").split(".")[0], self.IMPORTS_OK)

    def test_aucune_reference_materielle_ou_reseau(self):
        src = (RACINE / "simulateur.py").read_text(encoding="utf-8")
        for mot in self.INTERDITS:
            self.assertNotIn(mot, src, mot)

    def test_aucun_effet_de_bord_a_l_import(self):
        autorises = (ast.Expr, ast.Import, ast.ImportFrom, ast.Assign,
                     ast.AnnAssign, ast.FunctionDef, ast.ClassDef, ast.If)
        arbre = ast.parse((RACINE / "simulateur.py").read_text(encoding="utf-8"))
        for noeud in arbre.body:
            self.assertIsInstance(noeud, autorises, type(noeud).__name__)

    def test_sortie_par_defaut_dans_dossier_de_travail(self):
        self.assertEqual(S.RACINE.name, "cerveau-serre")
        self.assertEqual((S.RACINE / "sorties").name, "sorties")


def math_nan():
    import math
    return math.nan


if __name__ == "__main__":
    unittest.main(verbosity=2)
