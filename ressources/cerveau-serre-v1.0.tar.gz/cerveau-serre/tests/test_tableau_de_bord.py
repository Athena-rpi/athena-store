#!/usr/bin/env python3
"""Tests du tableau de bord local du cerveau de serre (T21).

Tout est vérifié sur des données SIMULÉES en mémoire : aucune mesure réelle,
aucun GPIO, aucun fichier écrit, aucun réseau.
"""
from __future__ import annotations

import importlib.util
import pathlib
import sys
import unittest

RACINE = pathlib.Path(__file__).resolve().parents[1]


def _charger(nom: str, fichier: pathlib.Path):
    spec = importlib.util.spec_from_file_location(nom, fichier)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"module introuvable : {fichier}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


tdb = _charger("tdb_sous_test", RACINE / "tableau_de_bord.py")


class TestDonneesSimulees(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = tdb.donnees()

    def test_source_etiquetee(self):
        self.assertEqual(self.d["source"], "simule")
        self.assertIn("DONNEES SIMULEES", self.d["avertissement"])
        self.assertEqual(self.d["jour_reference"], "2026-11-22")
        self.assertEqual(self.d["graine"], tdb.GRAINE_DEFAUT)

    def test_quatre_scenarios_etiquetes(self):
        self.assertEqual(len(self.d["scenarios"]), 4)
        for sc in self.d["scenarios"]:
            x = self.d["par_scenario"][sc]
            self.assertEqual(x["source"], "simule")
            self.assertEqual(x["scenario"], sc)
            self.assertEqual(x["graine"], tdb.GRAINE_DEFAUT)
            self.assertIn("DONNEES SIMULEES", json_avertissement_ok(x, self.d))

    def test_jour__reference_24_pas(self):
        for sc in self.d["scenarios"]:
            jour = self.d["par_scenario"][sc]["jour"]
            self.assertEqual(len(jour), 24, sc)
            self.assertTrue(all(e["instant"].startswith("2026-11-22") for e in jour), sc)

    def test_decisions_coherentes(self):
        for sc in self.d["scenarios"]:
            x = self.d["par_scenario"][sc]
            jour = x["jour"]
            r = x["reserves"]
            self.assertEqual(r["cycles_jour"], sum(1 for e in jour if e["arroser"]), sc)
            self.assertEqual(r["cycles_total"], x["resume"]["arrosages"], sc)
            self.assertEqual(len(x["alertes_jour"]), sum(1 for e in jour if e["alerte"]), sc)
            self.assertEqual(len(x["alertes"]), x["resume"]["alertes"], sc)
            for e in jour:
                self.assertIn(e["motif"], (
                    "donnee_invalide", "cuve_vide", "hors_fenetre", "hysterese",
                    "sol_humide", "delai", "ok",
                ))

    def test_reserves_coherentes(self):
        cfg = self.d["par_scenario"]["secheresse"]["configuration"]
        for sc in self.d["scenarios"]:
            r = self.d["par_scenario"][sc]["reserves"]
            self.assertEqual(r["eau_simulee_s_jour"],
                             r["cycles_jour"] * cfg["duree_s"], sc)
            self.assertEqual(r["eau_simulee_s_total"],
                             r["cycles_total"] * cfg["duree_s"], sc)
            self.assertEqual(r["cuve_pleine_jour"] + r["cuve_vide_jour"]
                             + r["cuve_inconnue_jour"], 24, sc)
            self.assertGreaterEqual(r["pct_cuve_pleine_jour"], 0.0, sc)
            self.assertLessEqual(r["pct_cuve_pleine_jour"], 100.0, sc)
            self.assertIsInstance(r["hysterese_finale"], bool, sc)

    def test_determinisme(self):
        self.assertEqual(self.d, tdb.donnees())


class TestRenduHtml(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = tdb.donnees()
        cls.html = tdb.page("panne_capteur", cls.d)

    def test_panneaux_presents(self):
        for marqueur in ('id="reserves"', 'id="decisions"', 'id="alertes"',
                         "Décisions du jour", "Réserves simulées",
                         "Alertes simulées", "DONNEES SIMULEES",
                         "aucune donnée réelle"):
            self.assertIn(marqueur, self.html)

    def test_aucun_placeholder(self):
        self.assertNotIn("{{", self.html)

    def test_selection_scenario(self):
        self.assertIn("panne_capteur", self.html)
        self.assertIn("capteur sol : donnée invalide", self.html)
        self.assertIn("class=\"arrosage\"", self.html)

    def test_scenario_inconnu_rebascule(self):
        self.assertEqual(tdb.scenario_demande({"scenario": ["../secrets"]}),
                         tdb.SCENARIO_DEFAUT)
        self.assertEqual(tdb.scenario_demande({"scenario": ["cuve_vide"]}), "cuve_vide")
        self.assertEqual(tdb.scenario_demande({}), tdb.SCENARIO_DEFAUT)

    def test_loopback_et_port(self):
        self.assertEqual(tdb.HOST, "127.0.0.1")
        self.assertEqual(tdb.PORT, 8082)


def json_avertissement_ok(x: dict, d: dict) -> str:
    """Le scénario porte l'avertissement global du jeu de données."""
    return d["avertissement"] if x["source"] == "simule" else ""


if __name__ == "__main__":
    unittest.main(verbosity=2)
