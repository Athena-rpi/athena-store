"""Tests du moteur de décision — stdlib uniquement, sans capteur ni relais."""

from .moteur import Config, Decision, MOTIFS, decider  # noqa: F401

__all__ = ["Config", "Decision", "MOTIFS", "decider"]
