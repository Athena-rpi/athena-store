#!/usr/bin/env python3
"""Tests du moteur de décision du cerveau de serre.

Aucun matériel, aucun paquet tiers. Un unittest discover suffit :

    python3 -m unittest discover -s store/products/cerveau-serre/tests -v
"""
from __future__ import annotations

import ast
import datetime as dt
import importlib.util
import math
import pathlib
import sys
import unittest

RACINE = pathlib.Path(__file__).resolve().parent.parent


def _charger():
    spec = importlib.util.spec_from_file_location("moteur_sous_test", RACINE / "moteur.py")
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod       # requis par dataclasses sous Python 3.13
    spec.loader.exec_module(mod)
    return mod


M = _charger()
MIDI = dt.datetime(2026, 11, 22, 12, 0, 0)
HIER = MIDI - dt.timedelta(days=1)


def appeler(**kw):
    base = {"sol": 20.0, "cuve_pleine": True, "maintenant": MIDI,
            "dernier_cycle": HIER}
    base.update(kw)
    return M.decider(**base)


class TestRegleNominale(unittest.TestCase):
    """La règle du kit : seuil, cuve, fenêtre, délai."""

    def test_cas_nominal(self):
        d = appeler()
        self.assertTrue(d.arroser)
        self.assertEqual(d.motif, "ok")
        self.assertEqual(d.duree_s, 30)
        self.assertTrue(d.etat_hysterese)
        self.assertIsNone(d.alerte)
        self.assertEqual(d.horodatage, "2026-11-22T12:00:00")
        self.assertIn("25 %", d.detail)

    def test_heure_6_incluse(self):
        self.assertTrue(appeler(maintenant=MIDI.replace(hour=6)).arroser)

    def test_heure_20h59_incluse(self):
        self.assertTrue(appeler(maintenant=MIDI.replace(hour=20, minute=59)).arroser)

    def test_heure_21_exclue(self):
        d = appeler(maintenant=MIDI.replace(hour=21))
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "hors_fenetre")

    def test_heure_5_bloquee(self):
        self.assertEqual(appeler(maintenant=MIDI.replace(hour=5)).motif, "hors_fenetre")

    def test_delai_exact_600_autorise(self):
        d = appeler(dernier_cycle=MIDI - dt.timedelta(seconds=600))
        self.assertTrue(d.arroser)
        self.assertEqual(d.motif, "ok")

    def test_delai_599_bloque(self):
        d = appeler(dernier_cycle=MIDI - dt.timedelta(seconds=599))
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "delai")

    def test_timestamp_epoch_equivalent(self):
        self.assertEqual(appeler(), appeler(dernier_cycle=HIER.timestamp()))

    def test_aucun_cycle_precedent(self):
        self.assertTrue(appeler(dernier_cycle=None).arroser)

    def test_sol_au_seuil_bloque(self):
        d = appeler(sol=25.0)
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "sol_humide")

    def test_sol_juste_sous_le_seuil(self):
        self.assertTrue(appeler(sol=24.999).arroser)


class TestDefautSur(unittest.TestCase):
    """Toute donnée douteuse interdit l'arrosage et produit une alerte."""

    def _invalide(self, **kw):
        d = appeler(**kw)
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "donnee_invalide")
        self.assertIsNotNone(d.alerte)
        return d

    def test_sol_absent(self):
        self._invalide(sol=None)

    def test_sol_nan(self):
        self._invalide(sol=math.nan)

    def test_sol_infini(self):
        self._invalide(sol=math.inf)

    def test_sol_negatif(self):
        self._invalide(sol=-0.1)

    def test_sol_au_dessus_de_100(self):
        self._invalide(sol=100.1)

    def test_sol_booleen(self):
        self._invalide(sol=True)

    def test_sol_texte(self):
        self._invalide(sol="20")

    def test_sol_entier_gigantesque(self):
        self._invalide(sol=10 ** 400)

    def test_cuve_inconnue(self):
        self._invalide(cuve_pleine=None)

    def test_cuve_booleen_invalide(self):
        self._invalide(cuve_pleine="pleine")

    def test_cuve_vide_bloque_avec_alerte(self):
        d = appeler(cuve_pleine=False)
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "cuve_vide")
        self.assertEqual(d.alerte, "cuve vide")

    def test_dernier_cycle_dans_le_futur(self):
        self._invalide(dernier_cycle=MIDI + dt.timedelta(seconds=1))

    def test_fuseaux_melanges(self):
        self._invalide(maintenant=MIDI.replace(tzinfo=dt.timezone.utc))

    def test_instant_invalide(self):
        self._invalide(maintenant="midi")

    def test_etat_hysterese_invalide(self):
        self._invalide(en_hysterese="oui")

    def test_dernier_cycle_booleen(self):
        self._invalide(dernier_cycle=True)


class TestHysteresis(unittest.TestCase):
    """Après un cycle, attendre seuil + marge avant d'en autoriser un autre."""

    def test_cycle_pose_le_verrou(self):
        self.assertTrue(appeler().etat_hysterese)

    def test_sol_sous_seuil_et_sous_marge_reste_verrouille(self):
        d = appeler(sol=29.9, en_hysterese=True)
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "hysterese")
        self.assertTrue(d.etat_hysterese)

    def test_retour_a_30_rearme(self):
        d = appeler(sol=30.0, en_hysterese=True)
        self.assertFalse(d.arroser)
        self.assertEqual(d.motif, "sol_humide")
        self.assertFalse(d.etat_hysterese)

    def test_sequence_complete_rearmement_puis_cycle(self):
        etat = appeler().etat_hysterese
        self.assertTrue(etat)
        etat = appeler(sol=30.0, en_hysterese=etat).etat_hysterese
        self.assertFalse(etat)
        d = appeler(sol=22.0, en_hysterese=etat)
        self.assertTrue(d.arroser)
        self.assertEqual(d.motif, "ok")
        self.assertTrue(d.etat_hysterese)

    def test_verrou_avant_delai(self):
        d = appeler(sol=20.0, en_hysterese=True,
                    dernier_cycle=MIDI - dt.timedelta(seconds=10))
        self.assertEqual(d.motif, "hysterese")

    def test_marge_configurable(self):
        cfg = M.Config(marge_hysterese=10.0)
        self.assertEqual(appeler(sol=32.0, en_hysterese=True, config=cfg).motif,
                         "hysterese")
        self.assertEqual(appeler(sol=35.0, en_hysterese=True, config=cfg).motif,
                         "sol_humide")

    def test_marge_nulle_rearme_au_seuil(self):
        cfg = M.Config(marge_hysterese=0.0)
        d = appeler(sol=20.0, en_hysterese=True, config=cfg)
        self.assertEqual(d.motif, "hysterese")       # 20 < 25 : toujours verrouillé
        rearm = appeler(sol=25.0, en_hysterese=True, config=cfg)
        self.assertFalse(rearm.etat_hysterese)       # retour à 25 % : réarmé
        self.assertEqual(rearm.motif, "sol_humide")


class TestConfiguration(unittest.TestCase):
    """Une configuration incomplète ou invalide est un défaut sûr."""

    DICT = {
        "seuil_sec": 25.0, "duree_s": 30, "delai_min_s": 600,
        "heure_debut": 6, "heure_fin": 21, "marge_hysterese": 5.0,
    }

    def test_config_par_defaut_identique_au_dict(self):
        self.assertEqual(appeler(), appeler(config=dict(self.DICT)))

    def test_dict_incomplet_refuse(self):
        cfg = dict(self.DICT)
        del cfg["marge_hysterese"]
        self.assertEqual(appeler(config=cfg).motif, "donnee_invalide")

    def test_type_inattendu_refuse(self):
        d = M.decider(sol=20.0, cuve_pleine=True, maintenant=MIDI, config="25")
        self.assertEqual(d.motif, "donnee_invalide")
        self.assertIsNotNone(d.alerte)

    def test_seuil_hors_plage(self):
        with self.assertRaises(ValueError):
            M.Config(seuil_sec=200.0)

    def test_fenetre_inversee(self):
        with self.assertRaises(ValueError):
            M.Config(heure_debut=21, heure_fin=6)

    def test_rearmement_impossible(self):
        with self.assertRaises(ValueError):
            M.Config(seuil_sec=98.0, marge_hysterese=5.0)

    def test_duree_nulle(self):
        with self.assertRaises(ValueError):
            M.Config(duree_s=0)

    def test_bool_rejete(self):
        with self.assertRaises(ValueError):
            M.Config(seuil_sec=True)

    def test_nan_rejete(self):
        with self.assertRaises(ValueError):
            M.Config(delai_min_s=math.nan)

    def test_tous_les_motifs_declares(self):
        for motif in ("donnee_invalide", "cuve_vide", "hors_fenetre",
                      "hysterese", "sol_humide", "delai", "ok"):
            self.assertIn(motif, M.MOTIFS)


class TestPurete(unittest.TestCase):
    """Fonction déterministe, imports stdlib, aucun effet de bord à l'import."""

    IMPORTS_OK = {"__future__", "collections", "dataclasses",
                  "datetime", "math", "typing"}

    def test_deterministe(self):
        self.assertEqual(appeler(), appeler())

    def test_entrees_non_modifiees(self):
        cfg = dict(TestConfiguration.DICT)
        avant = dict(cfg)
        appeler(config=cfg)
        self.assertEqual(cfg, avant)

    def test_imports_stdlib(self):
        arbre = ast.parse((RACINE / "moteur.py").read_text(encoding="utf-8"))
        for noeud in ast.walk(arbre):
            if isinstance(noeud, ast.Import):
                for a in noeud.names:
                    self.assertIn(a.name.split(".")[0], self.IMPORTS_OK)
            elif isinstance(noeud, ast.ImportFrom):
                self.assertIn((noeud.module or "").split(".")[0], self.IMPORTS_OK)

    def test_aucun_effet_de_bord_a_l_import(self):
        autorises = (ast.Expr, ast.Import, ast.ImportFrom, ast.Assign,
                     ast.AnnAssign, ast.FunctionDef, ast.ClassDef)
        arbre = ast.parse((RACINE / "moteur.py").read_text(encoding="utf-8"))
        for noeud in arbre.body:
            self.assertIsInstance(noeud, autorises, type(noeud).__name__)


if __name__ == "__main__":
    unittest.main(verbosity=2)
