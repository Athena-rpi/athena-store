# Cerveau de serre — cahier des charges

**Version 1.0 — 2026-11-22**
**Statut : spécification. En attente de relecture de Jacob. Aucune diffusion, aucune publication, aucun achat.**

---

## 1. Objet et périmètre

Le « cerveau de serre » est un **produit logiciel autonome** : il décide, simule,
affiche et alerte. Il ne mesure rien, ne commande rien et n'achète rien.

Le périmètre de ce lot est **le logiciel seul** :

1. un **moteur de décision** d'arrosage, sans dépendance au matériel ;
2. un **simulateur déterministe** qui rejoue ce moteur sur des scénarios étiquetés ;
3. un **tableau de bord local** des décisions, réserves simulées et alertes ;
4. un **module d'alertes** sur seuils et défauts de données.

Le matériel (sondes, relais, pompe) passe au rang **d'option d'intégration** : le
produit est vendable et vérifiable sans lui. Ce choix est cohérent avec le gel
des projets de serre et des achats de matériel (2026-11-19) : aucun branchement,
aucune commande, aucun accès GPIO dans ce lot.

---

## 2. Point de départ : l'existant, lu et vérifié

Le produit `store/products/kit-serre/` sert de source de vérité. Les faits ci-dessous
ont été relus dans les fichiers le 2026-11-22.

| Élément réutilisable | Fichier | Ce qui y est réellement |
|---|---|---|
| Règle d'arrosage | `examples/arrosage.py`, `examples/decision.py` | `pompe ON` si sol < `SEUIL_SEC` (25 %) **et** cuve pleine **et** heure dans [6 h, 21 h[ **et** `time.time() - dernier_cycle >= DELAI_MIN_S` (600 s). Durée d'un cycle `DUREE_S` = 30 s. `maintenant` injectable pour la démo. |
| Sécurité actionneur | `examples/arrosage.py` | GPIO17 (BCM), logique 3,3 V, relais ouvert au repos, `finally` → `activer(False)`, chien de garde `WATCHDOG_S` = 600 s ; `lgpio` absent → relais inactif. |
| Défaut sûr | `arrosage.decider()` | `sol is None` ou cuve non pleine → `False` ; données absentes → pas d'arrosage. |
| Étallonage sol | `examples/config.yaml`, guide §5.3 | `v_air` 2,60 V, `v_eau` 1,10 V, seuil 25 %, fenêtre [6, 21], `watchdog_s` 600. |
| Rejet des valeurs | `examples/collecteur.py` | Plages par topic (`serre/air/temperature` −10..60, humidité 0..100, lux 0..120 000...) ; hors plage → **rien écrit** ; clé primaire `(ts, capteur)` → deux capteurs à la même seconde conservés. |
| Tests sans capteur | `tests/test_kit.py` | 18 tests stdlib : CRC8 Sensirion `CRC(0xBEEF)=0x92`, clamp sol et étalonnage incohérent → `None`, rejets, décision d'arrosage. |
| Tableau de bord existant | `examples/dashboard.json` | Grafana, 4 panneaux (températures, jauge humidité sol, lux, humidité air), source `frser-sqlite-datasource`. |
| Seuils d'alertes | `examples/config.yaml` | `air_temperature_min` 5, `air_temperature_max` 38, `sol_humidite_min` 20, `cuve_vide` 0. |
| État réel du Pi | `store/projets/serre/preuve.yml` | Bus activés mais **aucun capteur branché** (ROMs 1-Wire fantômes de famille `0x00`), pompe et débitmètre non installés. |

**Écart assumé avec l'existant :** la règle actuelle est un seuil sec unique
(25 %) sans hystérésis. Le nouveau moteur ajoute une bande d'hystérésis (§4.1) :
c'est une amélioration **spécifiée**, pas une fonctionnalité déjà livrée.

---

## 3. Architecture cible

```
scénarios (simulateur) ──> moteur.py ──> décisions horodatées ──┬──> alertes.py
        │                     │                                │
        │                     │ (défaut sûr, hystérésis)        └──> dashboard (127.0.0.1)
        └──> données SIMULÉES ─┘
                        │
                        └──> option : capteurs réels / GPIO / MQTT hors de ce lot
```

Aucun paquet tiers n'est requis : **stdlib Python 3.11+ uniquement**
(`argparse`, `dataclasses`, `datetime`, `json`, `csv`, `math`, `random`,
`http.server`, `unittest`). Aucune dépendance à `smbus2`, `lgpio`, `mosquitto`,
`sqlite3` de mesure, ni à un service systemd.

---

## 4. Spécification fonctionnelle

### 4.1 Moteur de décision (`moteur.py`)

- Fonction pure, déterministe, testable sans matériel : entrées = humidité du sol
  (%), état de la cuve, instant, date du dernier cycle, configuration ; sortie =
  décision + motif explicite.
- Règle nominale reprise du kit : arroser si `sol < seuil_sec`, cuve pleine,
  `heure_debut <= heure < heure_fin`, et délai minimal écoulé. Valeurs par défaut :
  `seuil_sec` 25 %, `duree_s` 30 s, `delai_min_s` 600 s, fenêtre [6 h, 21 h[.
- **Hystérésis** : une fois un cycle déclenché sous 25 %, un nouveau cycle n'est
  autorisé qu'après retour à `seuil_sec + marge` (marge par défaut 5 points,
  configurable). But : éviter l'oscillation autour du seuil.
- **Défaut sûr** : `None`, `NaN`, valeur hors plage `[0, 100]`, état de cuve
  inconnu, horodatage invalide ou configuration incomplète → **pas d'arrosage**
  et alerte ; jamais de « valeur par défaut favorable ».
- La décision porte un **motif** (`sol_sec`, `cuve_vide`, `hors_fenetre`,
  `delai`, `donnee_invalide`, `ok`) afin que le tableau de bord affiche pourquoi.
- Le module n'importe aucun pilote GPIO, n'ouvre aucun fichier au-delà de sa
  configuration et n'écrit aucun état matériel. Aucun effet de bord à l'import.

### 4.2 Simulateur

- Rejoue `moteur.py` pas à pas sur une journée ou une saison, avec un pas
  configurable (par défaut 1 h pour les courbes longues, 1 min pour un cycle).
- Scénarios livrés au minimum : **saison tempérée**, **sécheresse**, **cuve vide**,
  **panne capteur** (donnée absente/aberrante). Graine fixe par défaut : deux
  exécutions avec la même graine produisent des octets identiques.
- Chaque série produite porte `source: simule`, `scenario`, `graine`, et un
  horodatage de génération. Toute courbe porte visiblement « DONNÉES SIMULÉES ».
- Format de sortie : CSV/JSON lisible + courbe **SVG générée en stdlib**, sans
  dépendance graphique externe. Les fichiers sont écrits dans un dossier de
  travail, jamais diffusés automatiquement.

### 4.3 Tableau de bord local

- Serveur `http.server` sur **127.0.0.1 uniquement**, port configurable (8082 par
  défaut, pour ne pas collisionner avec 8081). Aucune écoute sur une interface
  externe.
- Reprend le style et la sobriété de `sys/health_web.py` : une page, peu de
  JavaScript, rendu serveur, pas de framework.
- Contenu : décisions du jour (horaire + motif), état des réserves **simulées**,
  alertes actives, et un badge permanent « SIMULATION — aucune donnée réelle ».
- Aucune valeur réelle n'est affichée ou suggérée : si une source réelle est
  absente, l'affichage l'indique explicitement, il n'invente pas de mesure.

### 4.4 Alertes

- Seuils repris de `examples/config.yaml` : température air hors `[5, 38] °C`,
  humidité du sol < 20 %, cuve à 0. Ajout : donnée manquante/invalide et dépassement
  du chien de garde (600 s).
- Trois niveaux `info` / `avertissement` / `critique` ; déduplication par
  (`type`, `scénario`, `fenêtre horaire`) ; horodatage et motif conservés.
- Une alerte **critique** (capteur en panne, cuve vide, Watchdog) impose l'arrêt
  de la décision d'arrosage, même si les autres conditions sont réunies.

---

## 5. Matériel : optionnel

Le matériel du kit (`store/products/kit-serre/pieces.csv`, 11 pièces, 70–115 $)
reste documenté **comme option d'intégration**, vendue séparément, sans achat
par Athéna et sans branchement sur le Pi dans ce lot. Le produit logiciel doit
être complet, testable et démontrable avec zéro capteur et zéro relais — c'est la
condition de sa viabilité pendant le gel des achats.

---

## 6. Limites et non-objectifs

- **Aucune mesure réelle** : les bus I2C/1-Wire du Pi sont vides ; le simulateur
  ne prétend pas représenter une serre existante.
- **Aucun pilotage matériel** : pas de GPIO, pas de relais, pas de pompe, pas de
  MQTT dans ce lot. Le « défaut sûr » est une propriété de la décision, pas une
  preuve de sécurité électrique.
- **Pas de garantie agronomique** : ni prévision météo, ni optimisation de
  rendement, ni modèle de culture ; la règle est celle du kit, documentée, pas
  validée sur une plante.
- **Pas de diffusion** : site, réseaux, courriels et push publics attendent la
  relecture de Jacob. Ce document est une spécification interne.
- **Périmètre des tests** : les tests couvrent la logique pure ; ils ne couvrent
  ni le câblage, ni l'étalonnage réel d'une sonde, ni le comportement d'une pompe.

---

## 7. Critères d'acceptation (à vérifier quand le code existera)

Ces commandes sont des **critères**, pas des résultats : les fichiers `moteur.py`,
`simulateur.py` et leurs tests n'existent pas encore à la date de ce document.

1. `python3 -m unittest discover -s store/products/cerveau-serre/tests` → 0 erreur,
   cas seuil / hystérésis / défaut sûr couverts, et limites non couvertes notées.
2. Deux exécutions du simulateur avec la même graine → fichiers **octet pour
   octet identiques** (`sha256sum` comparés).
3. `grep -R "lgpio\|smbus2\|GPIO\|paho" store/products/cerveau-serre/` → aucune
   dépendance matérielle dans le cœur du produit.
4. Curseur local : `curl -s http://127.0.0.1:8082/ | grep -i "SIMULATION"` →
   badge présent ; `ss -ltn` ne montre que 127.0.0.1 pour ce port.
5. Page produit FR + EN et manifeste de preuve cohérents avec le prix affiché,
   le matériel présenté en option, sans annonce publique.

---

## 8. Séquence du lot B7

| Id | Tâche | Dépend |
|---|---|---|
| T18 | cahier des charges (ce document) | — |
| T19 | `moteur.py` autonome + tests | T18 |
| T20 | simulateur déterministe + courbes | T19 |
| T21 | tableau de bord local | T20 |
| T22 | page produit FR/EN + manifeste, prix, accueil | T21 |
| T83 | tests du moteur (seuils, hystérésis, défaut sûr) | — |
| T84 | documentation d'usage | T83 |

---

## 9. Décisions laissées ouvertes (non bloquantes)

- Prix de vente du logiciel : à arrêter avant T22, en cohérence avec le kit à
  9 USDC et la règle de garder ≥ 5 USDC de réserve.
- Marge d'hystérésis et pas de temps par défaut : valeurs proposées ci-dessus,
  confirmées par les tests de T83.
- Nom du port du tableau de bord : 8082 proposé, substituable sans changer l'API.
