#!/usr/bin/env python3
"""Cerveau de serre — démonstration en ligne de commande, sans matériel.

Reproduit exactement ce que le moteur décide : aucune mesure, aucun GPIO,
aucun fichier écrit. L'instant est figé pour que la sortie soit reproductible.
"""
from __future__ import annotations

import argparse
import datetime
import importlib.util
import pathlib
import sys

RACINE = pathlib.Path(__file__).resolve().parent

_spec = importlib.util.spec_from_file_location("cerveau_serre_moteur", RACINE / "moteur.py")
if _spec is None or _spec.loader is None:
    raise RuntimeError("moteur.py introuvable ou non chargeable")
moteur = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = moteur                 # requis par les dataclasses en 3.13
_spec.loader.exec_module(moteur)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Décision d'arrosage — démonstration déterministe")
    ap.add_argument("--sol", required=True,
                    help="humidité du sol en %%, ou « absent » si la sonde ne répond pas")
    ap.add_argument("--cuve", choices=("pleine", "vide", "inconnue"), default="pleine")
    ap.add_argument("--heure", type=int, default=12, help="heure locale (0-23)")
    ap.add_argument("--depuis", type=int, default=900,
                    help="secondes écoulées depuis le dernier cycle")
    ap.add_argument("--hysterese", action="store_true",
                    help="simule un cycle déjà déclenché (verrou d'hystérésis)")
    args = ap.parse_args(argv)

    if args.sol.strip().lower() in ("absent", "none", "nan"):
        sol = None
    else:
        sol = float(args.sol)
    cuve = {"pleine": True, "vide": False, "inconnue": None}[args.cuve]
    maintenant = datetime.datetime(2026, 11, 22, args.heure % 24, 0)
    dernier_cycle = maintenant - datetime.timedelta(seconds=args.depuis)

    d = moteur.decider(
        sol=sol,
        cuve_pleine=cuve,
        maintenant=maintenant,
        dernier_cycle=dernier_cycle,
        en_hysterese=args.hysterese,
    )

    sol_affiche = "absente (capteur en panne)" if sol is None else f"{sol:.1f} %"
    print(f"humidité du sol : {sol_affiche}")
    print(f"cuve            : {args.cuve}")
    print(f"instant         : {maintenant.isoformat(timespec='seconds')} "
          f"(fenêtre 6h–21h, seuil 25 %)")
    print(f"motif           : {d.motif}")
    print(f"alerte          : {d.alerte or 'aucune'}")
    print(f"décision        : POMPE {'ON' if d.arroser else 'OFF'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
