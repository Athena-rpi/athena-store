#!/usr/bin/env python3
"""Cerveau de serre — tableau de bord local (lot B7 / tâche T21).

Serveur HTTP loopback (127.0.0.1, port 8082 par défaut) affichant :
  * les décisions du jour de référence (24 pas, 2026-11-22) ;
  * l'état des réserves simulées (cuve, cycles, eau simulée, hystérésis) ;
  * les alertes des scénarios simulés.

Aucune donnée réelle : tous les chiffres proviennent de ``simulateur.produire``,
qui rejoue le moteur sur des séries générées à partir d'une graine fixe. Pas de
capteur, pas de GPIO, pas de réseau sortant, aucun fichier écrit, aucun effet de
bord durable. Le style CSS est repris de ``sys/health_web.py``.

Usage :
    python3 store/products/cerveau-serre/tableau_de_bord.py [--port 8082]
"""
from __future__ import annotations

import argparse
import html
import importlib.util
import json
import pathlib
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

RACINE = pathlib.Path(__file__).resolve().parent
HOST, PORT = "127.0.0.1", 8082
JOUR_REFERENCE = "2026-11-22"
SCENARIO_DEFAUT = "saison_temperee"
MAX_ALERTES = 12


def _charger_simulateur():
    """Charge simulateur.py sans effet global (même technique que ses tests)."""
    spec = importlib.util.spec_from_file_location("simulateur_tdb", RACINE / "simulateur.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("simulateur.py introuvable")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod          # requis par dataclasses sous Python 3.13
    spec.loader.exec_module(mod)
    return mod


_SIM = _charger_simulateur()
SCENARIOS = tuple(_SIM.SCENARIOS)
GRAINE_DEFAUT = _SIM.GRAINE_DEFAUT


def scenario_demande(q: dict[str, list[str]]) -> str:
    """Scénario demandé, ou scénario par défaut si inconnu (jamais de chemin libre)."""
    choix = (q.get("scenario") or [SCENARIO_DEFAUT])[0]
    return choix if choix in SCENARIOS else SCENARIO_DEFAUT


def donnees(graine: int | None = None) -> dict:
    """Construit en mémoire le jeu de données SIMULÉES, sans écriture disque."""
    graine = GRAINE_DEFAUT if graine is None else graine
    par_scenario: dict[str, dict] = {}

    for sc in SCENARIOS:
        fichiers = _SIM.produire(sc, graine=graine)
        doc = json.loads(fichiers[f"serre_{sc}_g{graine}.json"])
        series = doc["series"]
        jour = [e for e in series if e["instant"].startswith(JOUR_REFERENCE)]
        cfg = doc["configuration"]
        duree = cfg["duree_s"]

        cycles_jour = sum(1 for e in jour if e["arroser"])
        cycles_total = doc["resume"]["arrosages"]
        cp_jour = sum(1 for e in jour if e["cuve_pleine"] is True)
        cv_jour = sum(1 for e in jour if e["cuve_pleine"] is False)
        ci_jour = sum(1 for e in jour if e["cuve_pleine"] is None)
        cp_total = sum(1 for e in series if e["cuve_pleine"] is True)

        alertes = [
            {"instant": e["instant"], "motif": e["motif"], "alerte": e["alerte"]}
            for e in series if e["alerte"]
        ]
        alertes_jour = [
            {"instant": e["instant"], "motif": e["motif"], "alerte": e["alerte"]}
            for e in jour if e["alerte"]
        ]

        par_scenario[sc] = {
            "source": "simule",
            "scenario": sc,
            "graine": graine,
            "genere_le": doc["genere_le"],
            "jours": doc["jours"],
            "pas_minutes": doc["pas_minutes"],
            "configuration": cfg,
            "resume": doc["resume"],
            "jour": jour,
            "reserves": {
                "cycles_jour": cycles_jour,
                "cycles_total": cycles_total,
                "eau_simulee_s_jour": cycles_jour * duree,
                "eau_simulee_s_total": cycles_total * duree,
                "cuve_pleine_jour": cp_jour,
                "cuve_vide_jour": cv_jour,
                "cuve_inconnue_jour": ci_jour,
                "pct_cuve_pleine_jour": round(100.0 * cp_jour / len(jour), 1) if jour else None,
                "pct_cuve_pleine_total": round(100.0 * cp_total / len(series), 1) if series else None,
                "hysterese_finale": bool(jour[-1]["etat_hysterese"]) if jour else None,
            },
            "alertes": alertes,
            "alertes_jour": alertes_jour,
        }

    return {
        "source": "simule",
        "avertissement": "DONNEES SIMULEES — aucune mesure réelle",
        "jour_reference": JOUR_REFERENCE,
        "graine": graine,
        "scenarios": list(SCENARIOS),
        "par_scenario": par_scenario,
    }


# CSS repris à l'identique de sys/health_web.py, plus trois classes propres
# au tableau de bord (bandeau, surlignage des arrosages, optimisme nul).
HTML = """<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Athéna — Cerveau de serre (simulation)</title>
<style>
 body{background:#0f1115;color:#d7dae0;font:15px/1.5 ui-monospace,Menlo,Consolas,monospace;
      margin:0;padding:2rem;max-width:60rem}
 h1{font-size:1.15rem;letter-spacing:.08em;text-transform:uppercase;color:#8ab4f8;margin:0 0 1rem}
 .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:.75rem}
 .card{background:#171a21;border:1px solid #262b36;border-radius:.5rem;padding:.75rem .9rem}
 .card b{display:block;color:#7d8590;font-weight:400;font-size:.72rem;
         letter-spacing:.09em;text-transform:uppercase;margin-bottom:.35rem}
 .card span{font-size:1.25rem}
 .ok{color:#57ab5a}.warn{color:#e8a13d}.bad{color:#e5534b}
 table{width:100%;border-collapse:collapse;margin-top:1rem;font-size:.85rem}
 td,th{padding:.35rem .5rem;border-bottom:1px solid #262b36;text-align:left}
 th{color:#7d8590;font-weight:400}
 svg{width:100%;height:7rem;background:#171a21;border:1px solid #262b36;border-radius:.5rem;margin-top:1rem}
 footer{margin-top:1.2rem;color:#6e7681;font-size:.75rem}
 .panel{background:#171a21;border:1px solid #262b36;border-radius:.5rem;
        padding:.75rem .9rem;margin-top:1rem}
 .panel h2{font-size:.8rem;letter-spacing:.09em;text-transform:uppercase;color:#8ab4f8;
           margin:0 0 .6rem;font-weight:400}
 .panel .row{display:flex;gap:2rem;flex-wrap:wrap}
 .panel .lbl{display:block;color:#7d8590;font-size:.7rem;letter-spacing:.09em;
             text-transform:uppercase;margin-bottom:.25rem}
 .panel .num{font-size:1.3rem;color:#d7dae0}
 .panel .tag{color:#7d8590;font-size:.8rem}
 .panel .titre{margin-top:.2rem;color:#b6bdc7;font-size:.9rem}
 .panel .mut{color:#6e7681;font-size:.78rem;margin-top:.15rem}
 .journal{margin-top:.8rem;font-size:.8rem;color:#b6bdc7;line-height:1.6}
 .controles{list-style:none;margin:.7rem 0 0;padding:0;font-size:.83rem}
 .controles li{padding:.3rem 0;border-bottom:1px solid #262b36}
 .controles li:last-child{border-bottom:none}
 .controles .marque{display:inline-block;min-width:4.6rem;color:#57ab5a}
 .controles li.bad .marque{color:#e5534b}
 .controles li.mut .marque{color:#e8a13d}
 .actes{margin:.5rem 0 0;padding-left:1.2rem;font-size:.85rem}
 .actes li{padding:.25rem 0}
 .rapport{margin:.2rem 0 1rem;font-size:.85rem}
 a{color:#8ab4f8}
 .simule{border-color:#7a5c1e}
 .simule b{color:#e8a13d}
 tr.arrosage td{color:#57ab5a}
</style></head><body>
<h1>Athéna — Cerveau de serre · simulation</h1>
{{BANDEAU}}
{{SELECTEUR}}
{{RESERVES}}
{{DECISIONS}}
{{ALERTES}}
<footer> loopback seulement · <a href="/api/serre">/api/serre</a> · source: simule ·
 graine {{GRAINE}} · aucune donnée réelle · aucun actionneur piloté</footer>
</body></html>"""


def _e(v: object) -> str:
    """Échappement HTML de toute valeur affichée."""
    return html.escape("" if v is None else str(v), quote=True)


def bandeau(d: dict) -> str:
    return (f'<p class="panel simule"><b>Avertissement</b> {_e(d["avertissement"])}'
            f' — décisions et réserves issues du simulateur déterministe (graine {d["graine"]}).'
            ' Aucun capteur, aucune mesure, aucune commande matérielle.</p>')


def selecteur(sc: str, d: dict) -> str:
    liens = " · ".join(
        (f'<a class="warn" href="/?scenario={_e(s)}">{_e(s)}</a>' if s == sc
         else f'<a href="/?scenario={_e(s)}">{_e(s)}</a>')
        for s in d["scenarios"]
    )
    return (f'<div class="panel"><h2>Scénario affiché : {_e(sc)}</h2>'
            f'<div class="tag">{liens}</div>'
            f'<div class="mut">Jour de référence {_e(d["jour_reference"])} · '
            f'{_e(d["par_scenario"][sc]["pas_minutes"])} min/pas · '
            f'{_e(d["par_scenario"][sc]["jours"])} jours simulés · '
            f'généré {_e(d["par_scenario"][sc]["genere_le"])}</div></div>')


def reserves_panel(sc: str, d: dict) -> str:
    r = d["par_scenario"][sc]["reserves"]
    cfg = d["par_scenario"][sc]["configuration"]
    cartes = [
        ("cycles arrosage (jour)", r["cycles_jour"], ""),
        ("eau simulée (jour)", r["eau_simulee_s_jour"], " s"),
        ("cuve pleine (jour)", r["pct_cuve_pleine_jour"], " %"),
        ("alertes (jour)", len(d["par_scenario"][sc]["alertes_jour"]), ""),
        ("hystérésis en fin de jour", "oui" if r["hysterese_finale"] else "non", ""),
    ]
    html_cartes = "".join(
        f'<div class="card"><b>{_e(k)}</b><span>{_e(v)}{_e(u)}</span></div>'
        for k, v, u in cartes
    )
    lignes = []
    for s in d["scenarios"]:
        x = d["par_scenario"][s]
        rr = x["reserves"]
        lignes.append(
            "<tr><td>" + _e(s) + "</td>"
            "<td>" + _e(rr["cycles_total"]) + "</td>"
            "<td>" + _e(rr["eau_simulee_s_total"]) + " s</td>"
            "<td>" + _e(rr["pct_cuve_pleine_total"]) + " %</td>"
            "<td>" + _e(x["resume"]["alertes"]) + "</td>"
            "<td>" + _e(x["resume"]["pas"]) + "</td></tr>"
        )
    return (
        '<section class="panel" id="reserves"><h2>Réserves simulées</h2>'
        f'<div class="grid">{html_cartes}</div>'
        '<div class="mut">Seuil sec ' + _e(cfg["seuil_sec"]) + ' % · marge '
        + _e(cfg["marge_hysterese"]) + ' pts · cycle ' + _e(cfg["duree_s"])
        + ' s · délai ' + _e(cfg["delai_min_s"]) + ' s · fenêtre '
        + _e(cfg["heure_debut"]) + ' h–' + _e(cfg["heure_fin"]) + ' h. '
        'Cuve et eau sont des états de modèle, pas des mesures.</div>'
        '<table><thead><tr><th>scénario</th><th>cycles (total)</th>'
        '<th>eau simulée</th><th>cuve pleine</th><th>alertes</th>'
        '<th>pas</th></tr></thead><tbody>' + "".join(lignes) + '</tbody></table></section>'
    )


def decisions_panel(sc: str, d: dict) -> str:
    jour = d["par_scenario"][sc]["jour"]
    lignes = []
    for e in jour:
        classe = ' class="arrosage"' if e["arroser"] else ""
        heure = str(e["instant"])[11:16]
        sol = "—" if e["sol"] is None else f'{_e(e["sol"])} %'
        cuve = ("pleine" if e["cuve_pleine"] is True else
                "vide" if e["cuve_pleine"] is False else "inconnue")
        decision = ("ARROSER " + str(e["duree_s"]) + " s") if e["arroser"] else "ne pas arroser"
        lignes.append(
            f"<tr{classe}><td>{_e(heure)}</td><td>{sol}</td><td>{_e(e['sol_brut'])}</td>"
            f"<td>{_e(cuve)}</td><td>{_e(e['motif'])}</td><td>{_e(decision)}</td>"
            f"<td>{_e(e['alerte'] or '')}</td></tr>"
        )
    if not lignes:
        lignes = ['<tr><td colspan="7">aucune décision pour ce jour</td></tr>']
    return (
        '<section class="panel" id="decisions"><h2>Décisions du jour — '
        + _e(d["jour_reference"]) + ' · ' + _e(sc) + '</h2>'
        '<table><thead><tr><th>heure</th><th>sol effectif</th><th>sol brut</th>'
        '<th>cuve</th><th>motif</th><th>décision</th><th>alerte</th></tr></thead><tbody>'
        + "".join(lignes) + '</tbody></table>'
        '<div class="mut">Lignes vertes : arrosage simulé. « sol brut » est la valeur '
        'du scénario ; « sol effectif » tient compte de l’effet de modèle '
        '(arrosage simulé = 33 % sur les 3 pas suivants). DONNÉES SIMULÉES.</div></section>'
    )


def alertes_panel(d: dict) -> str:
    toutes = []
    for s in d["scenarios"]:
        for a in d["par_scenario"][s]["alertes"]:
            toutes.append((s, a))
    textes = [
        f"<tr><td>{_e(s)}</td><td>{_e(a['instant'])}</td>"
        f"<td>{_e(a['motif'])}</td><td>{_e(a['alerte'])}</td></tr>"
        for s, a in toutes[:MAX_ALERTES]
    ]
    if not textes:
        textes = ['<tr><td colspan="4">aucune alerte simulée</td></tr>']
    reste = len(toutes) - min(len(toutes), MAX_ALERTES)
    suite = (f'<div class="mut">{reste} autre(s) alerte(s) simulée(s) non affichée(s) '
             '(voir /api/serre).</div>') if reste else ""
    return (
        f'<section class="panel" id="alertes"><h2>Alertes simulées — {len(toutes)} au total</h2>'
        '<table><thead><tr><th>scénario</th><th>instant simulé</th><th>motif</th>'
        '<th>alerte</th></tr></thead><tbody>' + "".join(textes) + '</tbody></table>'
        + suite + '</section>'
    )


def page(sc: str, d: dict) -> str:
    """Rendu serveur complet, sans placeholder résiduel."""
    return (HTML.replace("{{BANDEAU}}", bandeau(d))
                .replace("{{SELECTEUR}}", selecteur(sc, d))
                .replace("{{RESERVES}}", reserves_panel(sc, d))
                .replace("{{DECISIONS}}", decisions_panel(sc, d))
                .replace("{{ALERTES}}", alertes_panel(d))
                .replace("{{GRAINE}}", str(d["graine"])))


class Handler(BaseHTTPRequestHandler):
    server_version = "AthenaSerreDash/1.0"

    def _send(self, body: bytes, ctype: str, code: int = 200) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj: dict, code: int = 200) -> None:
        self._send(json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"),
                   "application/json; charset=utf-8", code)

    def do_GET(self) -> None:  # noqa: N802
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/api/serre":
            return self._json(donnees())
        if u.path in ("/", "/index.html"):
            sc = scenario_demande(q)
            return self._send(page(sc, donnees()).encode("utf-8"),
                              "text/html; charset=utf-8")
        return self._json({"error": "not found", "source": "simule"}, 404)

    def log_message(self, format: str, *args) -> None:  # noqa: A002  (signature HTTP) silence
        pass


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Tableau de bord local du cerveau de serre (simulation)")
    ap.add_argument("--port", type=int, default=PORT, help=f"port loopback (défaut {PORT})")
    ap.add_argument("--hote", default=HOST, help="adresse d'écoute (défaut 127.0.0.1)")
    args = ap.parse_args(argv)
    srv = ThreadingHTTPServer((args.hote, args.port), Handler)
    print(f"Tableau de bord serre (DONNÉES SIMULÉES) sur http://{args.hote}:{args.port}",
          flush=True)
    srv.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
